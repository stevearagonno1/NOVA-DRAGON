#!/bin/bash
# ═══ NOVA ALERT PRO v6.0 — مشغّل بوت التنبيهات (Termux/لينكس) ═══
# الأسرار عبر البيئة فقط — لا مفاتيح داخل الكود
cd "$(dirname "$0")"

export TELEGRAM_TOKEN='8569299895:AAEvXcMLkkB9R1EzzH56tEW03A0Hex7hK9c'
export TELEGRAM_CHAT_ID='7112691967'
export GEMINI_API_KEY="AQ.Ab8RN6LRJd8r_pQ6fsVB6O9tJd7DYxvPzsaJuuFMKQeWImS4eg"

echo "🧪 اختبار ذاتي سريع قبل الإقلاع..."
python3 NOVA_ALERT.py --selftest
if [ $? -ne 0 ]; then
  echo "❌ الاختبار الذاتي فشل — لن يعمل البوت. أرسل لي ناتج الأمر أعلاه."
  exit 1
fi

echo "🚀 إقلاع NOVA ALERT PRO v6.0 (قاع+قمة | 12 عملة | محاكاة ورقية)..."
python3 NOVA_ALERT.py
