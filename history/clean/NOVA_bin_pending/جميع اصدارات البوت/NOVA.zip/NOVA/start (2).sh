#!/bin/bash

# إعدادات Binance
export BINANCE_ENV='testnet'
export BINANCE_API_KEY='06z5dvvciW3slfVb4D0CmSjEyYcFRIj16NA4M4GehKq5beIINJDk4wBNJ7TAu6r2'
export BINANCE_API_SECRET='mNPiTbwv6X3D3UynIUXMdQfX3cFtUoLVuYbwbSdUEE4OLjmJzmYvwgLiG8K8Bmny'


# إعدادات Telegram
export TELEGRAM_BOT_TOKEN="8569299895:AAEvXcMLkkB9R1EzzH56tEW03A0Hex7hK9c"
export TELEGRAM_CHAT_ID="7112691967"
 
# إعدادات الذكاء الاصطناعي (اختياري)
export AI_GATE_ENABLED='1'
export GEMINI_API_KEY="AQ.Ab8RN6LRJd8r_pQ6fsVB6O9tJd7DYxvPzsaJuuFMKQeWImS4eg"

# تشغيل البوت

export AUTO_TRADE='1'
export TOP_N_SYMBOLS='50'

python NOVA.py
