#!/bin/bash
# ═══ NOVA ZERO-WAIT v4.0.2 STRICT — مشغّل سكالبينج الصفقات السريعة ═══
# الأساس: نسخة الـ43% نجاح المُثبتة + القوانين الصارمة من الجديد
cd "$(dirname "$0")"

export BINANCE_ENV='testnet'
export BINANCE_API_KEY='06z5dvvciW3slfVb4D0CmSjEyYcFRIj16NA4M4GehKq5beIINJDk4wBNJ7TAu6r2'
export BINANCE_API_SECRET='mNPiTbwv6X3D3UynIUXMdQfX3cFtUoLVuYbwbSdUEE4OLjmJzmYvwgLiG8K8Bmny'
export TELEGRAM_BOT_TOKEN="8569299895:AAEvXcMLkkB9R1EzzH56tEW03A0Hex7hK9c"
export TELEGRAM_CHAT_ID="7112691967"
export AUTO_TRADE='1'

# ═══ أرقام V4.0 STRICT (عدّلها من هنا فقط) ═══
export SL_MIN_PCT='0.30'               # أضيق وقف
export SL_MAX_PCT='3.0'                # أوسع وقف
export BREAKEVEN_TRIGGER_PCT='0.50'    # قفل الأرباح عند + (فوق عمولة الجولة)
export BREAKEVEN_LOCK_PCT='0.45'       # الوقف يقفز فوق الدخول بصافٍ موجب
export TIME_STOP_SEC='60'              # خروج الزمن الذكي
export MIN_ATR_MOVE_PCT='0.08'         # منع العملات النائمة
export MIN_VOLUME_RATIO='1.2'          # منع السوق النائم
export MIN_TARGET_PCT='0.35'           # الهدف أكبر من العمولة
export GOV_MAX_LOSSES='3'              # حاكم العملة: 3 خسائر
export GOV_SYMBOL_COOLDOWN='600'       # عقوبة 10د على العملة فقط
export ORDER_BUDGET_MAX='40'           # ميزانية الأوامر/10ث
export DAILY_REPORT_HOUR='20'          # التقرير اليومي

echo "🧪 اختبار ذاتي قبل الإقلاع..."
python3 NOVA.py --selftest || { echo "❌ الاختبار فشل — لن يعمل البوت"; exit 1; }
echo "🚀 إقلاع NOVA ZERO-WAIT v4.0.2 STRICT..."
python3 NOVA.py
