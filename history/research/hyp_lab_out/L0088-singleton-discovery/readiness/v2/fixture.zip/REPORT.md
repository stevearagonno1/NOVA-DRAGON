# L0088 — اكتشاف إشارات منفردة لكل عملة

1. شبكة36 إعدادًا،9 عائلات،BTC/ETH/SOL،4h،ثلاث فترات تطوير2025.
2. المال والتكاليف: not measured.
3. صفقات: not measured؛تنبيهات وأحداث فقط.
4. معامل الربح: not measured.
5. تحقق مستقل أو أعمى: not measured؛كل الفترات سبق الاطلاع عليها.
6. مقابل الاحتفاظ: not measured؛خطوط التنبيه في baselines.json.
7. القرار: Defer الاعتماد؛هذه نتائج اكتشاف فقط.
8. التالي: مراجعة مستقلة ثم تجهيز مرحلة واحدة تالية.

## 1. هوية التجربة
| الحقل | القيمة |
|---|---|
| الحالات / تقييمات العملات والفترات |36 / 324 |
|نوع البيانات|شموع العقود التاريخيةUSDT-M؛ليست دفتر أوامر|

## 2. المال
| الحقل | الحالة |
|---|---|
|الربح/التوقع/الرسوم/معامل الربح|not measured|

## 3. الإشارات المشتركة — جميع الحالات دون إسقاط
|الإشارة|تنبيهات|ملتقط / أحداث|الدقة|الاسترجاع|أضعف دقة فترة|الجودة|
|---|---:|---:|---:|---:|---:|---|
|BB_10_2|15|1/7|6.67%|14.29%|0.00%|INSUFFICIENT_SAMPLE|
|BB_10_2.5|4|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|BB_20_2|9|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|BB_20_2.5|2|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|BB_30_2|3|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|BB_30_2.5|4|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|CCI_10_-150|9|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|CCI_10_-100|12|7/7|58.33%|100.00%|33.33%|INSUFFICIENT_SAMPLE|
|CCI_14_-150|11|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|CCI_14_-100|9|5/7|55.56%|71.43%|33.33%|INSUFFICIENT_SAMPLE|
|CCI_21_-150|9|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|CCI_21_-100|8|5/7|62.50%|71.43%|50.00%|INSUFFICIENT_SAMPLE|
|EMA_RECLAIM_10|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|EMA_RECLAIM_20|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|EMA_RECLAIM_30|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|DONCHIAN_RECLAIM_10|12|6/7|50.00%|85.71%|33.33%|INSUFFICIENT_SAMPLE|
|DONCHIAN_RECLAIM_20|10|6/7|60.00%|85.71%|50.00%|INSUFFICIENT_SAMPLE|
|DONCHIAN_RECLAIM_40|9|6/7|66.67%|85.71%|60.00%|INSUFFICIENT_SAMPLE|
|OBV_EMA_5_20|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|OBV_EMA_10_30|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|OBV_EMA_20_50|7|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|TAKER_PRESSURE_1_0.52|15|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|TAKER_PRESSURE_1_0.56|15|1/7|6.67%|14.29%|0.00%|INSUFFICIENT_SAMPLE|
|TAKER_PRESSURE_3_0.52|15|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|TAKER_PRESSURE_3_0.56|15|1/7|6.67%|14.29%|0.00%|INSUFFICIENT_SAMPLE|
|TAKER_PRESSURE_6_0.52|15|1/7|6.67%|14.29%|0.00%|INSUFFICIENT_SAMPLE|
|TAKER_PRESSURE_6_0.56|15|2/7|13.33%|28.57%|0.00%|INSUFFICIENT_SAMPLE|
|SQUEEZE_BREAK_20|0|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|SQUEEZE_BREAK_30|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|RSI_RECLAIM_10_30|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|RSI_RECLAIM_10_40|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|RSI_RECLAIM_14_30|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|RSI_RECLAIM_14_40|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|RSI_RECLAIM_21_30|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|RSI_RECLAIM_21_40|8|0/7|0.00%|0.00%|0.00%|INSUFFICIENT_SAMPLE|
|MACD_REFERENCE_12_26_9|8|1/7|12.50%|14.29%|0.00%|INSUFFICIENT_SAMPLE|

## 4. الحركة والمخاطر
|القياس|المصدر|
|---|---|
|lag/MAE/MFE لكل تنبيه|alerts.json؛بوحدةATR دون تنفيذ مالي|
|السحب/الخسارة المالية|not measured|

## 5. الفترات والثبات
|العملة|أحداث الفترات الثلاث|
|---|---|
|BTCUSDT|[0, 1, 1]|
|ETHUSDT|[1, 1, 1]|
|SOLUSDT|[0, 1, 1]|

تفاصيل324 تقييمًا،والحالات الصفرية،فيresults.json. الاختيار يرتب أدنى دقة فترة قبل حدWilson الوصفي والاسترجاع؛لا نختار قمة فترة منفردة.

## 6. المقارنات وخيارات التطوير
|العملة|مرشحو العائلات المؤهلون|
|---|---|
|BTCUSDT|BB:None، CCI:None، DONCHIAN_RECLAIM:None، EMA_RECLAIM:None، MACD_REFERENCE:None، OBV_EMA:None، RSI_RECLAIM:None، SQUEEZE_BREAK:None، TAKER_PRESSURE:None|
|ETHUSDT|BB:None، CCI:None، DONCHIAN_RECLAIM:None، EMA_RECLAIM:None، MACD_REFERENCE:None، OBV_EMA:None، RSI_RECLAIM:None، SQUEEZE_BREAK:None، TAKER_PRESSURE:None|
|SOLUSDT|BB:None، CCI:None، DONCHIAN_RECLAIM:None، EMA_RECLAIM:None، MACD_REFERENCE:None، OBV_EMA:None، RSI_RECLAIM:None، SQUEEZE_BREAK:None، TAKER_PRESSURE:None|

NONE/EVERY_BAR/EVERY_5_BARS محفوظة بكل أصل وفترة فيbaselines.json. المرشح العائلي يجهز بحثًا لاحقًا؛ليس تحققًا للتخصيص أو اعتمادًا.

## 7. شروط الجودة والحدود
|الشرط|الحالة|
|---|---|
|الهدف|دقة70%،استرجاع30%،عينة100/20 لكلعملة،دقةعملة55%،Wilson60%،وسيطlag≤1|
|دلالة مصححة وتحقق مستقل|not measured؛لاp-value أو دعوى تفوق استدلالية من اكتشاف|
|نتيجة إيجابية|DISCOVERY_TARGET_ONLY إن تحققت؛لاAdopt|

## المصطلحات
|المصطلح|المعنى|
|---|---|
|Precision|ملتقط/تنبيهات|
|Recall|ملتقط/كل أحداث الصعود|
|Wilson|حدوصفي يفترض استقلالًا؛لايصحح الاختيار|

## أسماء العائلات
|العائلة|المعنى|
|---|---|
|OBV|حجم تراكمي موقّع باتجاه الإغلاق؛ليس تدفق أوامر فعليًا|
|TAKER_PRESSURE|نسبة حجم شراءtaker المجمع،دون إعادة بناء دفترالأوامر|
|SQUEEZE_BREAK|ضغط نطاق ثم اختراق خلالمهلةسببية|

أمر الأرقام: python3 tools/l0088/research88.py --inputs tools/l0087 --out MARKET_DIR. تفاصيل التعريفات والتسجيل فيdocs/lanes/L0088-SINGLETON-DISCOVERY.md.
