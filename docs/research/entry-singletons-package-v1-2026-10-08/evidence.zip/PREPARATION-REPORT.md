# PREPARATION REPORT — R5 (synthetic only, market_run=false)

Status: SYNTHETIC_ACCEPTANCE_PASS; remote publication status is recorded in the receipt, not here.

- Runtime: CPython 3.13.16 (allowed 3.13.x); no 3.12 claim.
- Grid: 226 settings, 2034 candidate cells, 4068 candidate rows + 36 controls = 4104 summary rows; zero rows retained: 1410.
- Independent audit: PASS; indicator checks 21; barrier checks 83; causal prefix checks 60; causal mask comparisons 13560.
- Resume: interrupt after BTC, reload, finish; differences 0; summary bytes compared in memory.
- Tamper: 5 of 5 mutations rejected with expected messages; 0 remote writes.
- Secret scan: PASS (rules and counts only; no values recorded).
- Storage: R3 duplicate CSVs replaced by one verified gzip under run/preserved-r3/ (lossless, byte-verified); storage categories follow the R5 section 15 table.
- Limits: synthetic fixtures only; no market data, no August, no performance claim; PULLBACK-EMA and TURN-RSI classifier dependence disclosed.
