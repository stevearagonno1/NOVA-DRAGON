from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;subprocess.run(['node',str(P/'pine_runtime/validate.cjs')],check=True)
x=json.loads((P/'pine_runtime/basic-values.json').read_text());c=[r['close'] for r in x['rows']]
e=[None]*len(c);e[19]=sum(c[:20])/20
for i in range(20,len(c)):e[i]=e[i-1]+2/21*(c[i]-e[i-1])
r=[None]*len(c);u=sum(max(c[i]-c[i-1],0) for i in range(1,15))/14;d=sum(max(c[i-1]-c[i],0) for i in range(1,15))/14;r[14]=100 if d==0 else 100-100/(1+u/d)
for i in range(15,len(c)):
 u=(u*13+max(c[i]-c[i-1],0))/14;d=(d*13+max(c[i-1]-c[i],0))/14;r[i]=100 if d==0 else 100-100/(1+u/d)
res={}
for k,expected in [('EMA20',e),('RSI14',r)]:
 a=[v['value'] for v in x['plots'][k]['data']];assert len(a)==len(expected)
 errors=[(i,aa,bb) for i,(aa,bb) in enumerate(zip(a,expected)) if (aa is None)!=(bb is None) or aa is not None and abs(aa-bb)>1e-9]
 res[k]={'comparisons':len(a),'numeric_comparisons':sum(v is not None for v in expected),'mismatches':len(errors),'examples':errors[:3]}
(P/'pine_runtime/BASIC-VALIDATION-V2.json').write_text(json.dumps(res,indent=2));assert all(v['mismatches']==0 for v in res.values());print(json.dumps(res))
