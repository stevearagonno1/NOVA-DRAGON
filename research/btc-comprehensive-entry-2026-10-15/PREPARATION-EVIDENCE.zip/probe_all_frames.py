from pathlib import Path
import concurrent.futures,subprocess,json,hashlib,time,datetime
P=Path(__file__).resolve().parent;inv=json.loads((P/'inventory.json').read_text());out=P/'runtime_readiness_v4';out.mkdir(exist_ok=True)
jobs=[(i,f,frame) for i,f in enumerate(inv['files']) if f['kind']=='source_script' for frame in [1,5,15,60]]
def one(job):
 i,f,frame=job;b=(P/'original_sources'/f'{i:03}.txt').read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['git_sha']
 source=P/'original_sources'/f'{i:03}.txt';conversion=False
 try:b.decode('utf-8')
 except UnicodeDecodeError:source=out/f'{i:03}-utf8.pine';source.write_text(b.decode('cp1256'));conversion=True
 r={'index':i,'source':f['path'],'source_blob':f['git_sha'],'frame':frame,'encoding_conversion':conversion}
 try:
  c=subprocess.run(['node',str(P/'pine_runtime/probe-v4.cjs'),str(source),'512',str(frame)],capture_output=True,text=True,timeout=10)
  r.update(json.loads(c.stdout));r['exit_code']=c.returncode;(out/f'{i:03}-{frame}-stderr.log').write_text(c.stderr)
 except subprocess.TimeoutExpired:r.update(status='READINESS_TIMEOUT_10S',admitted=False)
 except Exception as e:r.update(status='HARNESS_FAILED',error=str(e),admitted=False)
 (out/f'{i:03}-{frame}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
start=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rs=list(pool.map(one,jobs))
counts={str(frame):{s:sum(r['frame']==frame and r['status']==s for r in rs) for s in sorted({r['status'] for r in rs})} for frame in [1,5,15,60]}
result={'source_commit':inv['source_commit'],'runtime':'pinets@0.11.1','purpose':'default synthetic compatibility only; no parameter sweep, entry-rule extraction, market measurement or causality admission','counts_by_frame':counts,'elapsed_seconds':time.monotonic()-start,'records':rs,'all_entry_variants_ready':False}
(P/'ALL-FRAME-RUNTIME-READINESS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='records'},ensure_ascii=False))
