"""Fetch only pinned source files, verify Git blob bytes, and preserve existing evidence."""
from pathlib import Path
import urllib.request,urllib.parse,concurrent.futures,hashlib,json,gzip
P=Path(__file__).resolve().parent
inv=json.loads((P/'inventory.json').read_text()) if (P/'inventory.json').exists() else json.loads(gzip.decompress((P/'inventory.json.gz').read_bytes()))
(P/'original_sources').mkdir(exist_ok=True)
def fetch(pair):
 i,f=pair;p=P/'original_sources'/f'{i:03}.txt'
 def match(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['git_sha']
 if p.exists():
  b=p.read_bytes()
  if not match(b):raise RuntimeError('Existing source hash mismatch: '+f['path'])
  return True
 u='https://raw.githubusercontent.com/stevearagonno1/NOVA-DRAGON/'+inv['source_commit']+'/'+urllib.parse.quote(f['path'],safe='/')
 with urllib.request.urlopen(u,timeout=90) as r:b=r.read()
 if not match(b):raise RuntimeError('Downloaded source hash mismatch: '+f['path'])
 p.write_bytes(b);return True
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:count=sum(pool.map(fetch,enumerate(inv['files'])))
print(json.dumps({'git_blob_bytes_verified':count,'source_commit':inv['source_commit']}))
