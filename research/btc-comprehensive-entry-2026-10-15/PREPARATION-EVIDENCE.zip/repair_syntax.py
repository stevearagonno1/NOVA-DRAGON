"""Derived compatibility candidates only; preserve original bytes and do not admit signals."""
from pathlib import Path
import json,re,hashlib,subprocess,concurrent.futures
P=Path(__file__).resolve().parent;T=P/'derived_compatibility';T.mkdir(exist_ok=True)
manifest=[]
for i in [35,41,42,43,77,79,107,122]:
 p=P/'original_sources'/f'{i:03}.txt';s=p.read_text(encoding='utf-8');old=s;changes=[]
 if s.startswith('\ufeff'):s=s[1:];changes.append('Remove UTF-8 BOM for parser compatibility')
 if i==79 and s.startswith('/ ©'):s='/'+s;changes.append('Restore second slash on copyright comment; retain attribution')
 if re.search(r'\bfor int (\w+) =',s):s=re.sub(r'\bfor int (\w+) =',r'for \1 =',s);changes.append('Remove explicit int annotation on integer loop counter for parser compatibility')
 if i==43:
  expected="apikey = __REDACTED__'xxx', title='Api Key', group='Zignaly Settings')"
  assert expected in s;s=s.replace(expected,"apikey = 'NO_EXTERNAL_EXECUTION'",1);changes.append('Repair syntactically broken redacted key assignment with inert message placeholder; external execution remains disabled')
 if i==35:
  s=re.sub(r'\btimestamp\b(?!\s*\()', '_nova_timestamp_value',s);changes.append('Rename variable shadowing timestamp builtin; function calls retained; candidate requires semantic review')
 if i==77:
  s=re.sub(r'(?m)^(\s*)bgcolor\s*=',r'\1_nova_bgcolor_value =',s)
  s=s.replace('bgcolor=bgcolor)','bgcolor=_nova_bgcolor_value)');changes.append('Rename local table color variables shadowing bgcolor builtin; candidate requires semantic review')
 assert s!=old
 dst=T/f'{i:03}.pine';dst.write_text(s)
 r={'index':i,'original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'derived_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'changes':changes,'execution_admitted':False}
 try:
  c=subprocess.run(['node',str(P/'pine_runtime/probe.cjs'),str(dst)],capture_output=True,text=True,timeout=8)
  r['probe']=json.loads(c.stdout);r['exit_code']=c.returncode
 except Exception as e:r['probe']={'status':'HARNESS_FAILED','error':str(e)}
 manifest.append(r)
(T/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps([{'index':r['index'],'status':r['probe']['status'],'error':r['probe'].get('error')} for r in manifest],ensure_ascii=False))
