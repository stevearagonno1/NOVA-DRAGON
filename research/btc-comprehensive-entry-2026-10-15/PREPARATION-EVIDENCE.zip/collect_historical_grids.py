from pathlib import Path
import json,itertools,hashlib
P=Path(__file__).resolve().parent;rs=[]
def add(source,family,values,definition_status):
 for p in values:
  r={'source_document':source,'family':family,'parameters':p,'status':definition_status,'execution_admitted':False};r['draft_id']=hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':')).encode()).hexdigest();rs.append(r)
def combos(**kw):return [dict(zip(kw,vs)) for vs in itertools.product(*kw.values())]
s='docs/lanes/L0083-EXECUTION.md#4'
add(s,'T01_RSI',combos(length=[7,14,21],threshold=[20,25,30,35]),'NEEDS_PINNED_SEED_AND_PORT')
add(s,'T02_STOCH',[dict(length=n,smooth=d,threshold=t) for n,d in [(14,3),(21,5)] for t in [15,20,25]],'NEEDS_PORT')
add(s,'T03_STOCH_RSI',combos(length=[14],threshold=[.1,.2]),'NEEDS_EXACT_WINDOW_AND_SEED')
add(s,'T04_WILLIAMS_R',combos(length=[14,21],threshold=[-90,-80]),'NEEDS_PORT')
add(s,'T05_CCI',combos(length=[14,20],threshold=[-150,-100]),'NEEDS_PORT')
for code,family in [('T06','RSI14'),('T07','MACD12_26_9_HIST'),('T08','OBV'),('T09','TAKER_QUOTE_RATIO')]:add(s,code+'_DIVERGENCE_'+family,combos(window=[20,40],min_gap=[5],min_price_drop_atr=[.25]),'NEEDS_CAUSAL_PIVOT_DEFINITION_DO_NOT_BACKDATE')
add(s,'T10_VOLUME_Z',combos(z=[2,2.5,3],prior_window=[100],min_observations=[50],close_range_fraction_min=[2/3]),'NEEDS_STANDARD_DEVIATION_CONVENTION_AND_PORT')
add(s,'T11_TAKER_RATIO_Z',combos(z=[1.5,2,2.5],prior_window=[100],min_observations=[50]),'NEEDS_STANDARD_DEVIATION_CONVENTION_AND_PORT')
add(s,'T12_FORCE',combos(ema_length=[13]),'NEEDS_PINNED_SEED_AND_PORT')
add(s,'T13_CMF',combos(length=[14,20]),'NEEDS_ZERO_RANGE_CONVENTION_AND_PORT')
add(s,'T14_SWEEP',combos(window=[10,20,40]),'NEEDS_PORT')
add(s,'T15_FVG',[{'pattern':'low[i]>high[i-2]'}],'NEEDS_PORT_OR_CANONICAL_RECONCILIATION')
add(s,'T16_STRUCTURE_BREAK',combos(window=[3,5]),'NEEDS_EXACT_LOWER_LOW_CONTEXT')
add(s,'T17_DONCHIAN_FAIL',combos(window=[20,55]),'NEEDS_PORT')
add(s,'T18_CANDLE',[{'pattern':'HAMMER','lower_body_min':2,'upper_body_max':.5,'close_range_min':.5},{'pattern':'BULLISH_ENGULFING','body_containment':True}],'NEEDS_CAUSAL_LOCAL_LOW_CONTEXT')
add(s,'T19_EMA_CROSS',[{'fast':a,'slow':b} for a,b in [(10,30),(20,50),(50,200)]],'NEEDS_PINNED_SEED_AND_PORT')
add(s,'T20_MACD',[{'fast':a,'slow':b,'signal':c} for a,b,c in [(12,26,9),(8,21,5),(19,39,9)]],'NEEDS_PINNED_SEED_AND_PORT')
add(s,'T21_SUPERTREND',[{'atr_length':a,'multiplier':b} for a,b in [(10,3),(10,2),(14,3)]],'NEEDS_INITIALIZATION_CONVENTION_AND_PORT')
add(s,'T22_DI_ADX',combos(adx_threshold=[20,25]),'NEEDS_LENGTH_AND_INITIALIZATION')
add(s,'T23_AROON',combos(length=[14,25]),'NEEDS_TIE_CONVENTION_AND_PORT')
add(s,'T24_VORTEX',combos(length=[14,21]),'NEEDS_PORT')
add(s,'T25_BOLLINGER',[{'length':a,'multiplier':b} for a,b in [(20,2),(20,2.5),(50,2)]],'NEEDS_TOUCH_REENTRY_AND_STD_CONVENTION')
add(s,'T26_KELTNER',[{'length':20,'multiplier':2}],'NEEDS_ATR_AND_MIDLINE_DEFINITION')
add(s,'T27_ROLLING_VWAP',combos(window=[30],negative_sigma=[-1.5,-2]),'NEEDS_RECLAIM_AND_DEVIATION_CONVENTION')
assert len(rs)==76
s='docs/lanes/L0079-PARAMETER-VARIANT-SCREEN.md#4'
for family,vals in [('MSS',[{'length':n} for n in [3,5,8]]),('FVG',[{'pattern':'3BAR_BASE'}]),('SFP',[{'window':n} for n in [10,20,40]]),('RSI',[{'length':n} for n in [2,7,14]]),('MACD',[dict(zip(['fast','slow','signal'],p)) for p in [(8,21,5),(12,26,9),(19,39,9)]]),('EMA',[{'fast':a,'slow':b} for a,b in [(10,30),(20,50),(50,200)]]),('STOCH',[dict(zip(['length','smooth_k','smooth_d'],p)) for p in [(9,3,3),(14,3,3),(21,5,5)]]),('OBV',[{'sma_length':n} for n in [10,20,50]]),('MFI',[{'length':n} for n in [14,20,30]]),('CMF',[{'length':n} for n in [14,20,30]]),('BOLLINGER',[{'length':a,'multiplier':b} for a,b in [(20,1.5),(20,2),(50,2)]]),('ADXDI',[{'length':n,'threshold':22} for n in [14,20,28]]),('TURTLE',[{'window':n} for n in [20,55]]),('DONCHIAN',[{'window':n} for n in [20,55]])]:add(s,family,vals,'NEEDS_RECONCILIATION_WITH_FROZEN_SIGNAL_FORMULA')
assert len(rs)==114
out={'status':'HISTORICAL_PARAMETER_DRAFTS_NOT_EXECUTABLE_VARIANTS','source_commit':'6d0226a03b84656e14b94dd8a37e39332cc2f68f','by_source':{s:sum(r['source_document']==s for r in rs) for s in sorted({r['source_document'] for r in rs})},'records':rs,'limitations':['not added to canonical52 as if unique; semantic overlaps require reconciliation','old success horizons, gates, financial metrics and combinations are not adopted','paper76 may differ from executable52 and is not proof of76 valid ports','VPFR remains named pending rather than inventing its source or anchor']}
(P/'HISTORICAL-GRIDS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({'records':len(rs),'by_source':out['by_source']}))
