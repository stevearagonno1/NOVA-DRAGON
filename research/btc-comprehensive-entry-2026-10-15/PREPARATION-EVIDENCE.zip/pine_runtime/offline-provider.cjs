// Offline-only smoke provider. Never substitutes another symbol or invents order flow.
function createProvider(rows){
 return {configure(){},async getSymbolInfo(){return {tickerid:'BINANCE:BTCUSDT',ticker:'BTCUSDT',prefix:'BINANCE',root:'BTCUSDT',basecurrency:'BTC',currency:'USDT',timezone:'UTC',type:'crypto',session:'24x7',mintick:.01,pricescale:100,minmove:1,pointvalue:1,volumetype:'base',mincontract:.00001};},async getMarketData(symbol,tf){
  const [sym,modifier]=symbol.split(';');
  if(!['BTCUSDT','BINANCE:BTCUSDT'].includes(sym))throw Error('UNSUPPLIED_SYMBOL: '+symbol);
  if(modifier&&!['standard','heikinashi'].includes(modifier))throw Error('UNSUPPLIED_CHART_MODIFIER: '+modifier);
  const m=/^(\d*)([DWMhH]?)$/.exec(tf);if(!m)throw Error('UNSUPPLIED_FRAME: '+tf);
  const n=Number(m[1]||1),unit=m[2]||'';if(n<1)throw Error('UNSUPPLIED_FRAME: '+tf);
  function bounds(t){
   if(unit==='M'){
    const d=new Date(t),ym=d.getUTCFullYear()*12+d.getUTCMonth(),k=Math.floor(ym/n)*n;
    return [Date.UTC(Math.floor(k/12),k%12,1),Date.UTC(Math.floor((k+n)/12),(k+n)%12,1)];
   }
   const dur=n*(unit==='D'?1440:unit==='W'?10080:unit.toLowerCase()==='h'?60:1)*60000;
   const anchor=unit==='W'?345600000:0;const start=Math.floor((t-anchor)/dur)*dur+anchor;return [start,start+dur];
  }
  let out=[],bar=null,end=0,count=0;
  function commit(){if(bar&&bar.openTime>=rows[0].openTime&&end<=rows.at(-1).closeTime&&count===(end-bar.openTime)/60000)out.push(bar);}
  for(const r of rows){let [start,stop]=bounds(r.openTime);
   if(!bar||start!==bar.openTime){commit();bar={openTime:start,closeTime:stop,open:r.open,high:r.high,low:r.low,close:r.close,volume:r.volume};end=stop;count=1;}
   else {bar.high=Math.max(bar.high,r.high);bar.low=Math.min(bar.low,r.low);bar.close=r.close;bar.volume+=r.volume;count++;}
  }commit();
  if(out.length===0)throw Error('SYNTHETIC_HISTORY_TOO_SHORT_FOR_FRAME: '+tf);
  if(modifier==='heikinashi'){
   let po=null,pc=null;out=out.map(r=>{const close=(r.open+r.high+r.low+r.close)/4,open=po===null?(r.open+r.close)/2:(po+pc)/2;po=open;pc=close;return {...r,open,close,high:Math.max(r.high,open,close),low:Math.min(r.low,open,close)};});
  }
  return out;
 }};
}
module.exports={createProvider};
