const fs = require('fs');
const {PineTS,Indicator}=require('pinets');
const source=fs.readFileSync(process.argv[2],'utf8');
const rows=Array.from({length:Number(process.argv[3]||512)},(_,i)=>{
 const close=100+i*.001+Math.sin(i*.17)*2+Math.sin(i*.031)*5;
 const open=close+Math.cos(i*.17)*.2;
 return {open,high:Math.max(open,close)+.3,low:Math.min(open,close)-.3,close,volume:100+Math.abs(Math.sin(i*.3))*50,openTime:1759276800000+i*60000,closeTime:1759276859999+i*60000};
});
let logs=[];console.log=console.warn=console.error=(...args)=>{if(logs.length<5)logs.push(args.map(String).join(' ').slice(0,300));};
global.fetch=async()=>{throw Error('NETWORK_DISABLED_FOR_READINESS: external data/library is not supplied');};
(async()=>{let start=performance.now();try{
 const provider={configure(){},async getSymbolInfo(){return{tickerid:'BINANCE:BTCUSDT',ticker:'BTCUSDT',prefix:'BINANCE',root:'BTCUSDT',basecurrency:'BTC',currency:'USDT',timezone:'UTC',type:'crypto',session:'24x7',mintick:.01,pricescale:100,minmove:1,pointvalue:1,volumetype:'base',mincontract:.00001};},async getMarketData(symbol,tf){
 if(!['BTCUSDT','BINANCE:BTCUSDT'].includes(symbol))throw Error('UNSUPPLIED_SYMBOL: '+symbol);
 const m=/^(\d*)([DWhH]?)$/.exec(tf);const unit=m?.[2]||'';const mins=m?(Number(m[1]||1)*(unit==='D'?1440:unit==='W'?10080:unit.toLowerCase()==='h'?60:1)):NaN;if(!Number.isInteger(mins)||mins<1)throw Error('UNSUPPLIED_FRAME: '+tf);
 let out=[];for(let i=0;i+mins<=rows.length;i+=mins){let chunk=rows.slice(i,i+mins);out.push({openTime:chunk[0].openTime,closeTime:chunk.at(-1).closeTime,open:chunk[0].open,close:chunk.at(-1).close,high:Math.max(...chunk.map(r=>r.high)),low:Math.min(...chunk.map(r=>r.low)),volume:chunk.reduce((a,r)=>a+r.volume,0)});}return out;
 }};
 const engine=new PineTS(provider,'BTCUSDT','1',rows.length);
 const ind=new Indicator(source);
 const ctx=await engine.run(ind);
 process.stdout.write(JSON.stringify({status:'DEFAULT_SYNTHETIC_RUN_ONLY',bars:rows.length,elapsed_ms:performance.now()-start,plots:Object.keys(ctx.plots||{}),result_length:ctx.result?.length,logs,admitted:false}));
}catch(e){process.stdout.write(JSON.stringify({status:'RUNTIME_FAILED',elapsed_ms:performance.now()-start,error:e.message,stack:e.stack?.slice(0,1800),logs,admitted:false}));process.exitCode=1;}})();
