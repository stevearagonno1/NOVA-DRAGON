const fs = require('fs');
const {PineTS,Indicator}=require('pinets');
const source=fs.readFileSync(process.argv[2],'utf8');
const rows=Array.from({length:Number(process.argv[3]||512)},(_,i)=>{
 const close=100+i*.001+Math.sin(i*.17)*2+Math.sin(i*.031)*5;
 const open=close+Math.cos(i*.17)*.2;
 return {open,high:Math.max(open,close)+.3,low:Math.min(open,close)-.3,close,volume:100+Math.abs(Math.sin(i*.3))*50,openTime:1759276800000+i*60000,closeTime:1759276859999+i*60000};
});
let logs=[];console.log=console.warn=console.error=(...args)=>{if(logs.length<5)logs.push(args.map(String).join(' ').slice(0,300));};
global.fetch=async()=>{throw Error('NETWORK_DISABLED_FOR_READINESS: external data/library is not supplied');};
(async()=>{let start=performance.now();try{
 const engine=new PineTS(rows,'BTCUSDT','1');
 const ind=new Indicator(source); if(!ind.prop.timeframe) ind.prop.timeframe="1";
 const ctx=await engine.run(ind);
 process.stdout.write(JSON.stringify({status:'DEFAULT_SYNTHETIC_RUN_ONLY',bars:rows.length,elapsed_ms:performance.now()-start,plots:Object.keys(ctx.plots||{}),result_length:ctx.result?.length,logs,admitted:false}));
}catch(e){process.stdout.write(JSON.stringify({status:'RUNTIME_FAILED',elapsed_ms:performance.now()-start,error:e.message,stack:e.stack?.slice(0,1800),logs,admitted:false}));process.exitCode=1;}})();
