const {PineTS}=require('pinets');const fs=require('fs');
const rows=Array.from({length:300},(_,i)=>{let close=100+i*.01+Math.sin(i*.17)*3;return{open:close+.1,close,high:close+.3,low:close-.3,volume:10+i%9,openTime:1759276800000+i*60000,closeTime:1759276859999+i*60000};});
(async()=>{const source=fs.readFileSync(__dirname+'/basic.pine','utf8');const ctx=await new PineTS(rows).run(source);fs.writeFileSync(__dirname+'/basic-values.json',JSON.stringify({rows,plots:ctx.plots}));})();
