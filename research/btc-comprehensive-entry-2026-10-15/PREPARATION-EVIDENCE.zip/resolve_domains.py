"""Resolve finite declared domains without inventing search limits or execution readiness."""
from pathlib import Path
import ast,json,re,hashlib,decimal,collections
P=Path(__file__).resolve().parent
INV=json.loads((P/'inventory.json').read_text());D=decimal.Decimal
class Unknown(Exception):pass
def split(s):
 out=[];start=0;depth=0;q=None;esc=False
 for i,c in enumerate(s):
  if q:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c==q:q=None
  elif c in "'\"":q=c
  elif c in '([{':depth+=1
  elif c in ')]}':depth-=1
  elif c==',' and depth==0:out.append(s[start:i].strip());start=i+1
 out.append(s[start:].strip());return out

def val(s,env):
 s=s.strip()
 if re.fullmatch(r'#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?',s):return {'pine_color':s.lower()}
 if re.fullmatch(r'(color|line|size|position|text|display|barmerge|currency|format|scale|location|shape|plot|xloc|yloc|session)\.[A-Za-z_]+',s):return {'pine_enum':s}
 if s in env:return env[s]
 if s in ['open','high','low','close','hl2','hlc3','ohlc4','hlcc4']:return {'price_series':s}
 s=re.sub(r'\btrue\b','True',s);s=re.sub(r'\bfalse\b','False',s)
 def visit(n):
  if isinstance(n,ast.Constant) and isinstance(n.value,(str,int,float,bool,type(None))):return n.value
  if isinstance(n,ast.Name) and n.id in env:return env[n.id]
  if isinstance(n,(ast.List,ast.Tuple)):return [visit(a) for a in n.elts]
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd)):
   a=visit(n.operand)
   if isinstance(a,(int,float)):return -a if isinstance(n.op,ast.USub) else a
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):
   a,b=visit(n.left),visit(n.right)
   if type(a)==type(b) and isinstance(a,(str,int,float)):return a+b
  if isinstance(n,ast.Attribute):
   name=ast.unparse(n)
   if re.fullmatch(r'(color|line|size|position|text|display|barmerge|currency|format|scale|location|shape|plot|xloc|yloc|session)\.[A-Za-z_]+',name):return {'pine_enum':name}
  raise Unknown(s)
 try:return visit(ast.parse(s,mode='eval').body)
 except (SyntaxError,Unknown,TypeError,ValueError,OverflowError):raise Unknown(s)

def args(decl):
 tokens=split(decl[decl.index('(')+1:-1]);pos=[];kw={}
 for t in tokens:
  m=re.match(r'^([A-Za-z_]\w*)\s*=(?!=)(.*)$',t,re.S)
  if m:kw[m[1]]=m[2].strip()
  else:pos.append(t)
 return pos,kw

def resolve():
 records=[];files=[]
 for i,f in enumerate(INV['files']):
  b=(P/'original_sources'/f'{i:03}.txt').read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['git_sha']
  try:s=b.decode('utf-8-sig');enc='utf-8-sig'
  except UnicodeDecodeError:s=b.decode('cp1256');enc='cp1256'
  env={};lineenv={};byline=collections.defaultdict(list)
  for it in f['inputs']:byline[it['line']].append(it)
  for lineno,line in enumerate(s.splitlines(),1):
   for it in byline[lineno]:
    pos,kw=args(it['source_declaration']);typ=it['input_type'];r={'source_path':f['path'],'source_blob':f['git_sha'],'line':lineno,'input_type':typ,'declaration':it['source_declaration'],'semantic_entry_dependency':'NOT_REVIEWED','execution_admitted':False}
    r['parameter_id']=hashlib.sha256((f['git_sha']+':'+str(lineno)+':'+it['source_declaration']).encode()).hexdigest()
    for key,index in [('defval',0),('title',1),('minval',2),('maxval',3),('step',4)]:
     expr=kw.get(key,pos[index] if index<len(pos) and (key in ['defval','title'] or typ in ['input.int','input.float']) else None)
     if expr is not None:
      try:r[key]=val(expr,env)
      except Unknown:r[key+'_unresolved']=expr
    optionexpr=kw.get('options',pos[2] if typ=='input.string' and len(pos)>2 else None)
    if optionexpr is not None:
     try:
      options=val(optionexpr,env)
      if not isinstance(options,list):raise Unknown(optionexpr)
      r['domain']={'kind':'DECLARED_OPTIONS','values':options,'count':len(options)}
     except Unknown:r['domain']={'kind':'UNRESOLVED_OPTIONS','expression':optionexpr}
    elif typ=='input.bool' or typ=='input' and isinstance(r.get('defval'),bool):r['domain']={'kind':'BOOLEAN','values':[False,True],'count':2}
    elif typ in ['input.int','input.float'] or typ=='input' and type(r.get('defval')) in [int,float]:
     integer=typ=='input.int' or typ=='input' and type(r.get('defval')) is int
     if all(type(r.get(k)) in [int,float] for k in ['minval','maxval']) and ('step' in r or integer):
      lo,hi,step=map(lambda a:D(str(a)),[r['minval'],r['maxval'],r.get('step',1)])
      if step>0 and hi>=lo:
       count=int((hi-lo)//step)+1;r['domain']={'kind':'FINITE_DECLARED_RANGE','min':str(lo),'max':str(hi),'step':str(step),'count':count,'rule':'min+k*step <= max; default recorded separately; UI step is not proof of exhaustive accepted values'}
      else:r['domain']={'kind':'INVALID_DECLARED_RANGE'}
     else:r['domain']={'kind':'OPEN_NUMERIC_DOMAIN','reason':'finite min,max,step are not all declared; no invented bounds','known_default':r.get('defval')}
    elif typ=='input.color' or isinstance(r.get('defval'),dict) and ('pine_color' in r['defval'] or str(r['defval'].get('pine_enum','')).startswith('color.')):r['domain']={'kind':'COLOR_DOMAIN','entry_dependency':'not established; not automatically removed'}
    elif 'defval' not in r:r['domain']={'kind':'UNRESOLVED_DEFAULT_OR_DOMAIN'}
    else:r['domain']={'kind':'OPEN_OTHER_DOMAIN','known_default':r.get('defval')}
    records.append(r)
   # Only simple top-level immutable literal expressions; no runtime code is executed.
   m=re.match(r'^(?:(?:const|var)\s+)?(?:(?:string|int|float|bool|color)\s+)?([A-Za-z_]\w*)\s*=\s*(.*?)\s*$',line)
   if m and not m[2].lstrip().startswith('input'):
    try:env[m[1]]=val(m[2],env)
    except Unknown:env.pop(m[1],None)
  files.append({'path':f['path'],'git_sha':f['git_sha'],'encoding':enc,'bytes_verified':len(b),'inputs':len(f['inputs'])})
 counts=dict(collections.Counter(r['domain']['kind'] for r in records))
 out={'source_commit':INV['source_commit'],'status':'PARAMETER_DOMAIN_AUDIT_ONLY_NOT_EXECUTABLE_VARIANTS','finite_range_policy':'Declared min/max/step lattice is a candidate grid; floating input may accept intervening values. No claim every legal or known setting.','files':files,'counts':counts,'inputs':records,'execution_ready':False}
 (P/'RESOLVED-PARAMETERS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({'files':len(files),'inputs':len(records),'counts':counts,'defaults_resolved':sum('defval' in r for r in records)},ensure_ascii=False))
if __name__=='__main__':resolve()
