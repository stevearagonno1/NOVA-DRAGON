from pathlib import Path
import json,bisect,math
P=Path(__file__).resolve().parent/'pine_runtime';runs=json.loads((P/'MTF-REGRESSION-VALUES-V3.json').read_text());checks=[]
def ema(closes,n):
 a=[None]*len(closes)
 if len(a)>=n:
  a[n-1]=sum(v[2] for v in closes[:n])/n
  for i in range(n,len(a)):a[i]=a[i-1]+2/(n+1)*(closes[i][2]-a[i-1])
 return a
def same(a,b):return (a is None and b is None) or a is not None and b is not None and abs(a-b)<=1e-7
for run in runs:
 if not run['patched']:checks.append({'test':'original reproduces runtime error','frame':run['frame'],'pass':run['status']=='RUNTIME_ERROR'});continue
 frame=run['frame'];assert run['status']=='PASS_RUN_ONLY';primary=run['requests'][0]['closes']
 for target,n in [(1,10),(3,20),(5,30)]:
  name=f'tf{target}_ema{n}';candidates=[r for r in run['requests'] if r['args'][1]==str(target)]
  req=run['requests'][0] if target==frame else candidates[0] if target>frame else candidates[-1]
  data=req['closes'];ev=ema(data,n);ends=[v[1] for v in data];expected=[]
  for start,end,_ in primary:
   j=bisect.bisect_right(ends,end)-1
   expected.append(None if j<0 or target<frame and data[j][0]<start else ev[j])
  actual=[v[1] for v in run['plots'][name]];errors=[{'bar':i,'actual':a,'expected':b} for i,(a,b) in enumerate(zip(actual,expected)) if not same(a,b)]
  checks.append({'test':'independent SMA-seeded EMA and completed-bar alignment','frame':frame,'bars':run['bars'],'series':name,'comparisons':len(actual),'errors':len(errors),'examples':errors[:4],'pass':not errors and len(actual)==len(expected)})
for frame in [1,5]:
 full=next(r for r in runs if r['patched'] and r['frame']==frame and r['bars']==120);short=next(r for r in runs if r['patched'] and r['frame']==frame and r['bars']==80)
 for name in full['plots']:
  a=full['plots'][name][:80];b=short['plots'][name];bad=[i for i,(x,y) in enumerate(zip(a,b)) if x[0]!=y[0] or not same(x[1],y[1])]
  checks.append({'test':'prefix stability 120 versus80 bars','frame':frame,'series':name,'comparisons':len(b),'errors':len(bad),'examples':bad[:4],'pass':not bad and len(b)==80})
out={'status':'PASS_REGRESSION_ONLY' if all(c['pass'] for c in checks) else 'REGRESSION_MISMATCH','checks':checks,'universal_runtime_admitted':False};(P/'MTF-INDEPENDENT-REFERENCE-V3.json').write_text(json.dumps(out,indent=2));print(json.dumps(out));raise SystemExit(0 if all(c['pass'] for c in checks) else 1)
