from pathlib import Path
import concurrent.futures,json,subprocess,time,hashlib
P=Path(__file__).resolve().parent;O=P/'repair_iteration';O.mkdir(exist_ok=True)
jobs=[('original',i,P/'original_sources'/f'{i:03}.txt') for i in [7,16]]+[('derived',i,P/'derived_compatibility'/f'{i:03}.pine') for i in [35,41,42,43,77,79,107,122]]
def one(j):
 kind,i,p=j;start=time.monotonic();r={'source_kind':kind,'index':i,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frame':1,'bars':120,'entry_admitted':False}
 try:
  c=subprocess.run(['node',str(P/'pine_runtime/probe-v6.cjs'),str(p),'120','1'],capture_output=True,text=True,timeout=60);r.update(json.loads(c.stdout));r['exit_code']=c.returncode
 except subprocess.TimeoutExpired:r.update(status='READINESS_TIMEOUT_60S',elapsed_seconds=time.monotonic()-start)
 except Exception as e:r.update(status='HARNESS_ERROR',error=str(e))
 (O/f'{kind}-{i:03}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rs=list(pool.map(one,jobs))
(P/'repair_iteration/REAL-SOURCE-RECHECK.json').write_text(json.dumps({'scope':'selected original and explicitly derived compatibility source smoke recheck, not all sources/frames/settings or market outcomes','records':rs,'universal_ready':False},ensure_ascii=False,indent=2))
print(json.dumps([{'kind':r['source_kind'],'index':r['index'],'status':r['status'],'error':r.get('error')} for r in rs],ensure_ascii=False))
