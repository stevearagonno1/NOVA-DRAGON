"""Explicit syntax-only derived sources; preserve source and previous repairs."""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
O=P/'repair_round2';O.mkdir(exist_ok=True)
records=[]
for index in (43,77,122):
    original=P/'derived_compatibility'/f'{index:03}.pine'
    source=original.read_text(); revised=source; edits=[]
    if index==77:
        old='array.unshift(zigzagpivots, value=value)'
        assert revised.count(old)==1
        revised=revised.replace(old,'array.unshift(zigzagpivots, value)')
        edits.append({'old':old,'new':'array.unshift(zigzagpivots, value)','reason':'Same argument position; native runtime does not unwrap named value argument.'})
    else:
        # Only names exclusive to line objects, excluding existing namespace calls.
        pattern=re.compile(r'(?<![\w.])([A-Za-z_]\w*(?:(?:\.\w+)(?:\([^()\n]*\))?)*)\.(get_x1|get_x2|get_y1|get_y2|set_xy1|set_xy2)\(')
        def convert(m):
            receiver,method=m.groups()
            if receiver=='line':return m.group(0)
            old=m.group(0)
            new='line.'+method+'('+receiver+('' if method.startswith('get_') else ', ')
            edits.append({'old':old,'new':new,'reason':'Use existing line namespace with identical receiver and arguments; preserve na handling.'})
            return new
        revised=pattern.sub(convert,revised)
        if index==43:
            assert revised.count('x.delete()')==2
            revised=revised.replace('x.delete()','line.delete(x)')
            edits.append({'old':'x.delete()','new':'line.delete(x)','count':2})
    out=O/f'{index:03}.pine';out.write_text(revised)
    records.append({'index':index,'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'derived_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'edits':edits,'entry_admitted':False})
(O/'SOURCE-CHANGES.json').write_text(json.dumps(records,indent=2))
print(json.dumps([{'index':r['index'],'edits':len(r['edits'])} for r in records]))
