const fs=require('fs'),assert=require('assert');
const {PineTS}=require('../pine_runtime/patched/pinets.min.cjs');
const {createProvider}=require('../pine_runtime/historical-provider.cjs');
const pre='//@version=5\nindicator("repair-regression")\n';
const fixtures={
 named:pre+'var a = array.new_float(0)\narray.unshift(a, value=close)\nplot(array.get(a, 0), "value")\n',
 positional:pre+'var a = array.new_float(0)\narray.unshift(a, close)\nplot(array.get(a, 0), "value")\n',
 method:pre+'var line x = line.new(0, 1, 1, 2)\nx.set_xy2(bar_index, close)\nplot(x.get_x2(), "x")\nplot(x.get_y2(), "y")\n',
 namespace:pre+'var line x = line.new(0, 1, 1, 2)\nline.set_xy2(x, bar_index, close)\nplot(line.get_x2(x), "x")\nplot(line.get_y2(x), "y")\n',
 missing:pre+'var line x = na\nline.set_xy2(x, bar_index, close)\nline.delete(x)\nplot(line.get_x1(x), "x")\n'};
async function run(s,n){let e=new PineTS(createProvider(1,n),'BTCUSDT','1',n);return (await e.run(s)).plots;}
(async()=>{let checks=[],values={};let failure='';try{await run(fixtures.named,30);}catch(e){failure=e.message;}
 assert(failure.includes('array.unshift'));checks.push('original named-argument defect reproduced');
 const p=await run(fixtures.positional,30);assert.equal(p.value.data.length,30);assert(p.value.data.every(x=>Number.isFinite(x.value)));checks.push('positional array argument returns finite prices');
 const m=await run(fixtures.method,30), n=await run(fixtures.namespace,30);
 for(const key of ['x','y']){assert.deepStrictEqual(m[key].data,n[key].data);checks.push('valid line method equals namespace '+key);}
 const missing=await run(fixtures.missing,30);assert(missing.x.data.every(x=>Number.isNaN(x.value)));checks.push('uninitialized line getters retain NaN');
 const short=await run(fixtures.namespace,20);for(const key of ['x','y']){assert.deepStrictEqual(n[key].data.slice(0,20),short[key].data);checks.push('line namespace prefix stable '+key);}
 values={array:p.value.data,line:n,missing:missing.x.data};
 fs.writeFileSync(__dirname+'/REPAIR-REGRESSION.json',JSON.stringify({status:'PASS_SCOPED_REPAIR_ONLY',checks,fixtures,values,original_error:failure,all_sources_ready:false},null,2));
 process.stdout.write(JSON.stringify({status:'PASS_SCOPED_REPAIR_ONLY',checks:checks.length}));
})().catch(e=>{process.stderr.write(e.stack);process.exitCode=1});
