# سجل إشارات الدخول المستقلة

حزمة تجهيز: 134 سجلًا؛ 52 تاريخية و6 نماذج شموع و76 مشتقة مكتملة التعريف. ليست جميع مصادر المكتبة، ولم تقَس دقة السوق.

الأطر لكل سجل: 1 و5 و15 و60 دقيقة. أسماء المشتقات لا تعني أن صيغها الأصلية الناقصة اختُبرت كما هي.

## aadb1a48bd262b24be3be6c8

الاسم: Aroon14_bull_x

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "tie": "earliest_extreme"}

التعريف: Window n+1; up/down=100*index of earliest maximum/minimum divided by n. Previous up<=down,current up>down.

## eac253402e3fef1fa9823483

الاسم: Aroon25_bull_x

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 25, "tie": "earliest_extreme"}

التعريف: Window n+1; up/down=100*index of earliest maximum/minimum divided by n. Previous up<=down,current up>down.

## a925c904c6fbc51f36c9945d

الاسم: BB20_2.0_reenter

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "length": 20, "multiplier": 2.0}

التعريف: Lower=SMA(C,n)-multiplier*population_SD(C,n). Previous C<=previous lower and current C>current lower.

## 417aa01ad196b330393ba2e6

الاسم: BB20_2.5_reenter

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "length": 20, "multiplier": 2.5}

التعريف: Lower=SMA(C,n)-multiplier*population_SD(C,n). Previous C<=previous lower and current C>current lower.

## 901b229e59351294049e61ba

الاسم: BB20_3.0_reenter

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "length": 20, "multiplier": 3.0}

التعريف: Lower=SMA(C,n)-multiplier*population_SD(C,n). Previous C<=previous lower and current C>current lower.

## 0a5f8840285d2c5a5b0c1d7a

الاسم: BullEngulfing

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {}

التعريف: Previous red,current green,current O<=previous C,current C>=previous O; every qualifying candle, no extra decline context.

## fbdf1f529453f23f21874378

الاسم: CCI14_xup_-100

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "threshold": -100.0}

التعريف: TP=HLC3; CCI=(TP-SMA(TP,n))/(.015*mean absolute deviation of TP window from its own mean); previous<threshold,current>=threshold; zero deviation unavailable.

## 61268aa4a123e75225e42ece

الاسم: CCI20_xup_-100

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 20, "threshold": -100.0}

التعريف: TP=HLC3; CCI=(TP-SMA(TP,n))/(.015*mean absolute deviation of TP window from its own mean); previous<threshold,current>=threshold; zero deviation unavailable.

## 933ddd8302578554f9df1ba7

الاسم: Donchian10_break

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"exclude_current": true, "length": 10}

التعريف: Upper=max prior n highs. Current C>upper on every qualifying bar.

## debfe7daf07062b1e656356c

الاسم: Donchian20_break

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"exclude_current": true, "length": 20}

التعريف: Upper=max prior n highs. Current C>upper on every qualifying bar.

## d2f3287aeffe36b524f23802

الاسم: Donchian20_fail

المصدر: tools/l0090/indicators84.py

النوع: historical_nonbullish_reference؛ الأصل: historical_executable_52

الإعدادات: {"exclude_current": true, "length": 20}

التعريف: Upper=max prior n highs. Current H>upper and C<=upper; upper breakout rejection, not bullish lower reclaim.

## 3c91913e9ce402c351aa177a

الاسم: Donchian55_break

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"exclude_current": true, "length": 55}

التعريف: Upper=max prior n highs. Current C>upper on every qualifying bar.

## 633a89881ce9e5b4129a7c8b

الاسم: EMA_x_20_200

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"fast": 20, "slow": 200}

التعريف: Previous fast EMA<=slow EMA and current fast EMA>slow EMA.

## 7ba1da17032e59cf2be50531

الاسم: EMA_x_20_50

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"fast": 20, "slow": 50}

التعريف: Previous fast EMA<=slow EMA and current fast EMA>slow EMA.

## 2d92553080f52e4da5a9f784

الاسم: EMA_x_50_200

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"fast": 50, "slow": 200}

التعريف: Previous fast EMA<=slow EMA and current fast EMA>slow EMA.

## d154b3ea65105b0d229d2593

الاسم: FVG_single

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"lookback": 2}

التعريف: Current L>H two bars earlier; current completed candle, every qualifying candle.

## 5ae7eb6e7f6d5ad8681dd56b

الاسم: Hammer

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"lower_body_min": 2, "upper_body_max": 1}

التعريف: Body=abs(C-O)>0,range>0,lower shadow>=2*body,upper shadow<=body. No decline context or required green close; every qualifying candle.

## 04ab66c7539fa448df2b1987

الاسم: MACD_12_26_9_xup

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"fast": 12, "signal": 9, "slow": 26}

التعريف: MACD=EMAfast-EMAslow; signal=EMA(MACD). Previous MACD<=signal and current MACD>signal.

## dc0c0901ed307b257e9044e0

الاسم: MACD_5_35_5_xup

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"fast": 5, "signal": 5, "slow": 35}

التعريف: MACD=EMAfast-EMAslow; signal=EMA(MACD). Previous MACD<=signal and current MACD>signal.

## 47c0257b6a32b2fa35769308

الاسم: MFI14_xup_20

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "threshold": 20.0}

التعريف: TP=HLC3; rawflow=TP*V. Sum positive/negative flow by sign of TP change, equal contributes zero; MFI=100-100/(1+positive/negative). Zero negative unavailable. Previous<threshold,current>=threshold.

## c217a9ce444b92c4a0952943

الاسم: PX_x_EMA200

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 200}

التعريف: Previous C<=previous EMA and current C>current EMA.

## de59f08e48ecaaf730e1ec9a

الاسم: PX_x_EMA50

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 50}

التعريف: Previous C<=previous EMA and current C>current EMA.

## 182bb4617cd1a16a074066a7

الاسم: RSI14_bull_divergence

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"left": 2, "length": 14, "lookback": 20, "right": 2}

التعريف: Successive confirmed price pivot lows, left=right=2. Emit at center+2 when new pivot low is lower and RSI at that pivot is finite and higher than previous pivot RSI, center separation<=20. Update preceding pivot on every confirmed pivot. Pivot equals minimum and is strictly below its immediate neighbors.

## 529aec1a03c8cb15aedb0e40

الاسم: RSI14_xup_20

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "threshold": 20.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## 503116bf138a5dfafaaac666

الاسم: RSI14_xup_25

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "threshold": 25.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## e1ebc43c57be489c882c9fa7

الاسم: RSI14_xup_30

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "threshold": 30.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## 934693acc6901bda3fec0e88

الاسم: RSI21_bull_divergence

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"left": 2, "length": 21, "lookback": 20, "right": 2}

التعريف: Successive confirmed price pivot lows, left=right=2. Emit at center+2 when new pivot low is lower and RSI at that pivot is finite and higher than previous pivot RSI, center separation<=20. Update preceding pivot on every confirmed pivot. Pivot equals minimum and is strictly below its immediate neighbors.

## de5003b23310fa67f89d6b03

الاسم: RSI21_xup_20

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 21, "threshold": 20.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## e2cb93ce1c75f9182b229d29

الاسم: RSI21_xup_25

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 21, "threshold": 25.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## 3ae0dc0c4fb4b2d828af3507

الاسم: RSI21_xup_30

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 21, "threshold": 30.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## 9d73ed0d7e03ecd8da6cd04a

الاسم: RSI7_xup_20

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 7, "threshold": 20.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## bc827ce55d258ca4e03df68b

الاسم: RSI7_xup_25

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 7, "threshold": 25.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## d2bfcd5bf1d5704ba93b54a0

الاسم: RSI7_xup_30

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 7, "threshold": 30.0}

التعريف: Historical RSI crosses from strictly below threshold to greater than or equal threshold.

## 361c220ee590ae3e32c37f19

الاسم: Stoch14_3_xup_15

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"d_length_unused_in_signal": 3, "length": 14, "threshold": 15.0}

التعريف: Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.

## b019ffb2b2ca0609c40db8b5

الاسم: Stoch14_3_xup_20

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"d_length_unused_in_signal": 3, "length": 14, "threshold": 20.0}

التعريف: Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.

## 91ad845c6776a6ccb05eff87

الاسم: Stoch14_3_xup_25

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"d_length_unused_in_signal": 3, "length": 14, "threshold": 25.0}

التعريف: Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.

## 8fe5154c7384fc4bbefd24b2

الاسم: Stoch21_5_xup_15

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"d_length_unused_in_signal": 5, "length": 21, "threshold": 15.0}

التعريف: Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.

## 241576b4485931aec44d2e82

الاسم: Stoch21_5_xup_20

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"d_length_unused_in_signal": 5, "length": 21, "threshold": 20.0}

التعريف: Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.

## ae881e06026afa9805a7fa54

الاسم: Stoch21_5_xup_25

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"d_length_unused_in_signal": 5, "length": 21, "threshold": 25.0}

التعريف: Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.

## fcda36b0f74d48cf5dc2f240

الاسم: TakerRatioZ_ge_1.5

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 1.5}

التعريف: Ratio=actual taker-buy base volume/base volume. Ratio z against full current-inclusive50window, population SD; z>=threshold. Zero volume or SD unavailable.

## 84c5429196165bbe27123f37

الاسم: TakerRatioZ_ge_2.0

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 2.0}

التعريف: Ratio=actual taker-buy base volume/base volume. Ratio z against full current-inclusive50window, population SD; z>=threshold. Zero volume or SD unavailable.

## 50113f7bfe2f2f82d5c6ace1

الاسم: TakerRatioZ_ge_2.5

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 2.5}

التعريف: Ratio=actual taker-buy base volume/base volume. Ratio z against full current-inclusive50window, population SD; z>=threshold. Zero volume or SD unavailable.

## 2e6c9df9c291e1cc4de65b8a

الاسم: TakerRatio_gt_0.48

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"threshold": 0.48}

التعريف: Actual taker-buy base volume/base volume strictly greater than threshold on every bar; zero volume unavailable.

## 3aff575002d23be7ccc67630

الاسم: TakerRatio_gt_0.5

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"threshold": 0.5}

التعريف: Actual taker-buy base volume/base volume strictly greater than threshold on every bar; zero volume unavailable.

## 5948c7c815ed8260df242a02

الاسم: TakerRatio_gt_0.52

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"threshold": 0.52}

التعريف: Actual taker-buy base volume/base volume strictly greater than threshold on every bar; zero volume unavailable.

## 31115c5dbfe3229e495ce3ac

الاسم: TakerRatio_gt_0.55

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"threshold": 0.55}

التعريف: Actual taker-buy base volume/base volume strictly greater than threshold on every bar; zero volume unavailable.

## 5a610d7258ecc047dfc746c3

الاسم: VolSpike_z1.5

المصدر: tools/l0090/indicators84.py

النوع: activity_only؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 1.5}

التعريف: Current volume z against full 50-bar window including current, population SD; z>=threshold. Activity only; zero SD unavailable.

## 2bb569a6103f52af92061301

الاسم: VolSpike_z2.0

المصدر: tools/l0090/indicators84.py

النوع: activity_only؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 2.0}

التعريف: Current volume z against full 50-bar window including current, population SD; z>=threshold. Activity only; zero SD unavailable.

## 44f79dfbaa37f8dced49ccb5

الاسم: VolSpike_z2.5

المصدر: tools/l0090/indicators84.py

النوع: activity_only؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 2.5}

التعريف: Current volume z against full 50-bar window including current, population SD; z>=threshold. Activity only; zero SD unavailable.

## f88fa6710d832bb8c3f8ac69

الاسم: VolSpike_z3.0

المصدر: tools/l0090/indicators84.py

النوع: activity_only؛ الأصل: historical_executable_52

الإعدادات: {"ddof": 0, "includes_current": true, "window": 50, "z_threshold": 3.0}

التعريف: Current volume z against full 50-bar window including current, population SD; z>=threshold. Activity only; zero SD unavailable.

## ee4b96873c81c2d66e5dff05

الاسم: WilliamsR14_xup_-80

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 14, "threshold": -80.0}

التعريف: WR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous<threshold,current>=threshold; zero range unavailable.

## 6736bfad8e02afdc693bf46c

الاسم: WilliamsR21_xup_-80

المصدر: tools/l0090/indicators84.py

النوع: bullish_candidate؛ الأصل: historical_executable_52

الإعدادات: {"length": 21, "threshold": -80.0}

التعريف: WR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous<threshold,current>=threshold; zero range unavailable.

## 8b9982168828bfa6aac73c56

الاسم: CANDLE92_hammer_2

المصدر: history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md

النوع: bullish_candidate؛ الأصل: historical_candle92_standalone

الإعدادات: {"pattern": "hammer", "value": 2}

التعريف: body>0 and <=.35*range, lower>=ratio*body, upper<=body, C>=L+.6*range; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.

## ae2abc7bfc3e19da2629e0ed

الاسم: CANDLE92_hammer_3

المصدر: history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md

النوع: bullish_candidate؛ الأصل: historical_candle92_standalone

الإعدادات: {"pattern": "hammer", "value": 3}

التعريف: body>0 and <=.35*range, lower>=ratio*body, upper<=body, C>=L+.6*range; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.

## 2947331b513dde68996319a6

الاسم: CANDLE92_engulf_1

المصدر: history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md

النوع: bullish_candidate؛ الأصل: historical_candle92_standalone

الإعدادات: {"pattern": "engulf", "value": 1}

التعريف: previous red,current green,O<=previous C,C>=previous O,body>=ratio*previous body; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.

## f978506c200246e1f3e29df9

الاسم: CANDLE92_engulf_1.25

المصدر: history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md

النوع: bullish_candidate؛ الأصل: historical_candle92_standalone

الإعدادات: {"pattern": "engulf", "value": 1.25}

التعريف: previous red,current green,O<=previous C,C>=previous O,body>=ratio*previous body; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.

## 56f2c4873cf39f774c9e0d80

الاسم: CANDLE92_morning_0.5

المصدر: history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md

النوع: bullish_candidate؛ الأصل: historical_candle92_standalone

الإعدادات: {"pattern": "morning", "value": 0.5}

التعريف: first red with body>=.5*range,middle body<=.3*first body,last green with body>=.5*range and C>=first C+fraction*first body; first and last ranges>0; no opening gap required; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.

## 79614ac117611a7123c41e67

الاسم: CANDLE92_morning_1

المصدر: history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md

النوع: bullish_candidate؛ الأصل: historical_candle92_standalone

الإعدادات: {"pattern": "morning", "value": 1}

التعريف: first red with body>=.5*range,middle body<=.3*first body,last green with body>=.5*range and C>=first C+fraction*first body; first and last ranges>0; no opening gap required; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.

## 816db4c067cf756e344e2449

الاسم: COMPLETED83_T01_RSI_{"length":7,"threshold":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 7, "threshold": 20}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 622dad7f5646f17543f08a0c

الاسم: COMPLETED83_T01_RSI_{"length":7,"threshold":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 7, "threshold": 25}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 26a0d509741008411ec8c958

الاسم: COMPLETED83_T01_RSI_{"length":7,"threshold":30}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 7, "threshold": 30}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 2c2dafbe9f8180ed8bf1082f

الاسم: COMPLETED83_T01_RSI_{"length":7,"threshold":35}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 7, "threshold": 35}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 7c46bb127f66d80374b2d52f

الاسم: COMPLETED83_T01_RSI_{"length":14,"threshold":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": 20}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## bd790e16831dca74847e8724

الاسم: COMPLETED83_T01_RSI_{"length":14,"threshold":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": 25}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## a372729b67b1c826a1cf1bd5

الاسم: COMPLETED83_T01_RSI_{"length":14,"threshold":30}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": 30}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## ba5da073a393c75ecc0d30c2

الاسم: COMPLETED83_T01_RSI_{"length":14,"threshold":35}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": 35}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 9b074a3777ee6a1bbbc82a7a

الاسم: COMPLETED83_T01_RSI_{"length":21,"threshold":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "threshold": 20}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 44ae6a1ffc06758e520c9ba5

الاسم: COMPLETED83_T01_RSI_{"length":21,"threshold":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "threshold": 25}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 677434207593abf929be74e1

الاسم: COMPLETED83_T01_RSI_{"length":21,"threshold":30}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "threshold": 30}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 5082adc39064097874625cef

الاسم: COMPLETED83_T01_RSI_{"length":21,"threshold":35}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "threshold": 35}

التعريف: SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.

## 71f852fa34368b20d49d3e21

الاسم: COMPLETED83_T02_STOCH_{"length":14,"smooth":3,"threshold":15}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "smooth": 3, "threshold": 15}

التعريف: K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.

## ff628dd172eb3a2eaa564c09

الاسم: COMPLETED83_T02_STOCH_{"length":14,"smooth":3,"threshold":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "smooth": 3, "threshold": 20}

التعريف: K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.

## e986301ffab7a8405076df4d

الاسم: COMPLETED83_T02_STOCH_{"length":14,"smooth":3,"threshold":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "smooth": 3, "threshold": 25}

التعريف: K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.

## b3fe8908fe14627ce4fe0c6a

الاسم: COMPLETED83_T02_STOCH_{"length":21,"smooth":5,"threshold":15}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "smooth": 5, "threshold": 15}

التعريف: K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.

## 077e9af19006c176e0cb1ce8

الاسم: COMPLETED83_T02_STOCH_{"length":21,"smooth":5,"threshold":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "smooth": 5, "threshold": 20}

التعريف: K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.

## f7e8071194a7d47350bf9b44

الاسم: COMPLETED83_T02_STOCH_{"length":21,"smooth":5,"threshold":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "smooth": 5, "threshold": 25}

التعريف: K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.

## 1e154a2e75066972df0b9c0f

الاسم: COMPLETED83_T03_STOCH_RSI_{"length":14,"threshold":0.1}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": 0.1}

التعريف: RSI uses length n, SMA-seeded Wilder; StochRSI=(RSI-min(RSI,n))/(max(RSI,n)-min(RSI,n)), no smoothing. Previous < threshold, current >=. Flat window unavailable.

## dad09daf3ec5439e7d27d16d

الاسم: COMPLETED83_T03_STOCH_RSI_{"length":14,"threshold":0.2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": 0.2}

التعريف: RSI uses length n, SMA-seeded Wilder; StochRSI=(RSI-min(RSI,n))/(max(RSI,n)-min(RSI,n)), no smoothing. Previous < threshold, current >=. Flat window unavailable.

## c7f41241caa4569481327de1

الاسم: COMPLETED83_T04_WILLIAMS_R_{"length":14,"threshold":-90}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": -90}

التعريف: WilliamsR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous < threshold and current >=. Full windows; zero range unavailable.

## 73ff2b4d8f0ad60e0e5ddf66

الاسم: COMPLETED83_T04_WILLIAMS_R_{"length":14,"threshold":-80}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": -80}

التعريف: WilliamsR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous < threshold and current >=. Full windows; zero range unavailable.

## 853ad27406737eceacff46d8

الاسم: COMPLETED83_T04_WILLIAMS_R_{"length":21,"threshold":-90}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "threshold": -90}

التعريف: WilliamsR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous < threshold and current >=. Full windows; zero range unavailable.

## 107ea6defaecd7c0c3d57b5a

الاسم: COMPLETED83_T04_WILLIAMS_R_{"length":21,"threshold":-80}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21, "threshold": -80}

التعريف: WilliamsR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous < threshold and current >=. Full windows; zero range unavailable.

## dbafd75da4dc6a17fcd239bf

الاسم: COMPLETED83_T05_CCI_{"length":14,"threshold":-150}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": -150}

التعريف: CCI=(TP-SMA(TP,n))/(.015*mean(abs(TP_window-window_mean))); TP=(H+L+C)/3. Previous < threshold, current >=. Zero deviation unavailable.

## 289f2af7d4aef7d1727583ba

الاسم: COMPLETED83_T05_CCI_{"length":14,"threshold":-100}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14, "threshold": -100}

التعريف: CCI=(TP-SMA(TP,n))/(.015*mean(abs(TP_window-window_mean))); TP=(H+L+C)/3. Previous < threshold, current >=. Zero deviation unavailable.

## d6c194c40cdd7d0c658ada8d

الاسم: COMPLETED83_T05_CCI_{"length":20,"threshold":-150}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 20, "threshold": -150}

التعريف: CCI=(TP-SMA(TP,n))/(.015*mean(abs(TP_window-window_mean))); TP=(H+L+C)/3. Previous < threshold, current >=. Zero deviation unavailable.

## 70183ea888e13f371c3c557c

الاسم: COMPLETED83_T05_CCI_{"length":20,"threshold":-100}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 20, "threshold": -100}

التعريف: CCI=(TP-SMA(TP,n))/(.015*mean(abs(TP_window-window_mean))); TP=(H+L+C)/3. Previous < threshold, current >=. Zero deviation unavailable.

## 2b357ee9fcda1476d01583da

الاسم: COMPLETED83_T06_DIVERGENCE_RSI14_{"min_gap":5,"min_price_drop_atr":0.25,"window":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 20}

التعريف: RSI14 bullish divergence; successive confirmed price pivots, left=2 right=2, center minimum and strictly below immediate neighbors; pivot gap 5..window inclusive; price drop >=.25*ATR14 at second pivot, oscillator higher. Emit at second pivot+2; update previous at every confirmed pivot.

## 2186b1a4a2d98fd0271c2084

الاسم: COMPLETED83_T06_DIVERGENCE_RSI14_{"min_gap":5,"min_price_drop_atr":0.25,"window":40}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 40}

التعريف: RSI14 bullish divergence; successive confirmed price pivots, left=2 right=2, center minimum and strictly below immediate neighbors; pivot gap 5..window inclusive; price drop >=.25*ATR14 at second pivot, oscillator higher. Emit at second pivot+2; update previous at every confirmed pivot.

## f05909b200bccc8bd75ed07d

الاسم: COMPLETED83_T07_DIVERGENCE_MACD12_26_9_HIST_{"min_gap":5,"min_price_drop_atr":0.25,"window":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 20}

التعريف: Same confirmed-pivot divergence using SMA-seeded MACD12/26/9 histogram; available only two bars after second pivot.

## 91523b07a0405607bd0801f1

الاسم: COMPLETED83_T07_DIVERGENCE_MACD12_26_9_HIST_{"min_gap":5,"min_price_drop_atr":0.25,"window":40}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 40}

التعريف: Same confirmed-pivot divergence using SMA-seeded MACD12/26/9 histogram; available only two bars after second pivot.

## 17fc651b5a6afddc2b5abd15

الاسم: COMPLETED83_T08_DIVERGENCE_OBV_{"min_gap":5,"min_price_drop_atr":0.25,"window":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 20}

التعريف: Same confirmed-pivot divergence using OBV initialized zero, adding/subtracting base volume on close change, unchanged for equal close.

## 90d1c70db01c6bed5cb7f8b1

الاسم: COMPLETED83_T08_DIVERGENCE_OBV_{"min_gap":5,"min_price_drop_atr":0.25,"window":40}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 40}

التعريف: Same confirmed-pivot divergence using OBV initialized zero, adding/subtracting base volume on close change, unchanged for equal close.

## b2993864ddfe360defd558e0

الاسم: COMPLETED83_T09_DIVERGENCE_TAKER_QUOTE_RATIO_{"min_gap":5,"min_price_drop_atr":0.25,"window":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 20}

التعريف: Same confirmed-pivot divergence using actual taker-buy quote volume / total quote volume; zero denominator unavailable.

## 093dae8fc397be816d190c78

الاسم: COMPLETED83_T09_DIVERGENCE_TAKER_QUOTE_RATIO_{"min_gap":5,"min_price_drop_atr":0.25,"window":40}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_gap": 5, "min_price_drop_atr": 0.25, "window": 40}

التعريف: Same confirmed-pivot divergence using actual taker-buy quote volume / total quote volume; zero denominator unavailable.

## c89327cccd9cc5770617bfe7

الاسم: COMPLETED83_T10_VOLUME_Z_{"close_range_fraction_min":0.6666666666666666,"min_observations":50,"prior_window":100,"z":2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"close_range_fraction_min": 0.6666666666666666, "min_observations": 50, "prior_window": 100, "z": 2}

التعريف: Volume z uses prior 100 bars, minimum 50 finite observations, population SD. z>=threshold AND (C-L)/(H-L)>=2/3; zero range or SD unavailable. Evaluated each qualifying closed candle, not edge-only.

## af2382ac01e6d5aab994ba11

الاسم: COMPLETED83_T10_VOLUME_Z_{"close_range_fraction_min":0.6666666666666666,"min_observations":50,"prior_window":100,"z":2.5}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"close_range_fraction_min": 0.6666666666666666, "min_observations": 50, "prior_window": 100, "z": 2.5}

التعريف: Volume z uses prior 100 bars, minimum 50 finite observations, population SD. z>=threshold AND (C-L)/(H-L)>=2/3; zero range or SD unavailable. Evaluated each qualifying closed candle, not edge-only.

## 48958acfedf092f6868533f4

الاسم: COMPLETED83_T10_VOLUME_Z_{"close_range_fraction_min":0.6666666666666666,"min_observations":50,"prior_window":100,"z":3}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"close_range_fraction_min": 0.6666666666666666, "min_observations": 50, "prior_window": 100, "z": 3}

التعريف: Volume z uses prior 100 bars, minimum 50 finite observations, population SD. z>=threshold AND (C-L)/(H-L)>=2/3; zero range or SD unavailable. Evaluated each qualifying closed candle, not edge-only.

## 072ff30d7529c28c5f1d035e

الاسم: COMPLETED83_T11_TAKER_RATIO_Z_{"min_observations":50,"prior_window":100,"z":1.5}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_observations": 50, "prior_window": 100, "z": 1.5}

التعريف: Actual taker-buy quote ratio z against prior 100 bars, minimum 50 finite, population SD; z>=threshold on each closed candle. Zero denominator or SD unavailable.

## 6dacdfc5522e64fdac82dc28

الاسم: COMPLETED83_T11_TAKER_RATIO_Z_{"min_observations":50,"prior_window":100,"z":2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_observations": 50, "prior_window": 100, "z": 2}

التعريف: Actual taker-buy quote ratio z against prior 100 bars, minimum 50 finite, population SD; z>=threshold on each closed candle. Zero denominator or SD unavailable.

## 474e692aed0df132783e7925

الاسم: COMPLETED83_T11_TAKER_RATIO_Z_{"min_observations":50,"prior_window":100,"z":2.5}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"min_observations": 50, "prior_window": 100, "z": 2.5}

التعريف: Actual taker-buy quote ratio z against prior 100 bars, minimum 50 finite, population SD; z>=threshold on each closed candle. Zero denominator or SD unavailable.

## 59136e95e45924d1aefa34d1

الاسم: COMPLETED83_T12_FORCE_{"ema_length":13}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"ema_length": 13}

التعريف: Force=(C-Cprevious)*base_volume; SMA-seeded EMA13 crosses from <=0 to >0.

## b434438f35bba936b2a403ca

الاسم: COMPLETED83_T13_CMF_{"length":14}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14}

التعريف: CMF=sum(((2*C-H-L)/(H-L))*V,n)/sum(V,n); zero H-L contributes zero money-flow multiplier; zero sum V unavailable. Cross <=0 to >0.

## 2d6539e81cde1ea10a6f016a

الاسم: COMPLETED83_T13_CMF_{"length":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 20}

التعريف: CMF=sum(((2*C-H-L)/(H-L))*V,n)/sum(V,n); zero H-L contributes zero money-flow multiplier; zero sum V unavailable. Cross <=0 to >0.

## 2c606facc238b3b4c82becb1

الاسم: COMPLETED83_T14_SWEEP_{"window":10}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 10}

التعريف: Current L < minimum of prior window lows AND C > same minimum; every qualifying bar.

## 7fba2dce4275c1a30328f481

الاسم: COMPLETED83_T14_SWEEP_{"window":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 20}

التعريف: Current L < minimum of prior window lows AND C > same minimum; every qualifying bar.

## f5cc944d160d9b100e418a15

الاسم: COMPLETED83_T14_SWEEP_{"window":40}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 40}

التعريف: Current L < minimum of prior window lows AND C > same minimum; every qualifying bar.

## d9cfec97670bbcbaf2139ca6

الاسم: COMPLETED83_T15_FVG_{"pattern":"low[i]>high[i-2]"}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"pattern": "low[i]>high[i-2]"}

التعريف: Three-bar bullish FVG: current L > H two bars ago; every qualifying bar, available at current close.

## 52059d465888a1310165714d

الاسم: COMPLETED83_T16_STRUCTURE_BREAK_{"window":3}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 3}

التعريف: DERIVED context completion: latest n prior lows minimum < preceding n lows minimum, and C crosses above maximum of n prior highs; previous C<=previous corresponding channel and current C>current channel.

## 98d1a6c8af43677991e37564

الاسم: COMPLETED83_T16_STRUCTURE_BREAK_{"window":5}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 5}

التعريف: DERIVED context completion: latest n prior lows minimum < preceding n lows minimum, and C crosses above maximum of n prior highs; previous C<=previous corresponding channel and current C>current channel.

## 1200a199e2e7f984f28fd39b

الاسم: COMPLETED83_T17_DONCHIAN_FAIL_{"window":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 20}

التعريف: Bullish lower Donchian recovery: current L < minimum prior n lows and current C > that minimum. Distinct from historical upper-break failure.

## f5b8665d86d9f5c04c33ea71

الاسم: COMPLETED83_T17_DONCHIAN_FAIL_{"window":55}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"window": 55}

التعريف: Bullish lower Donchian recovery: current L < minimum prior n lows and current C > that minimum. Distinct from historical upper-break failure.

## 34734675219dc4091abfce27

الاسم: COMPLETED83_T18_CANDLE_{"close_range_min":0.5,"lower_body_min":2,"pattern":"HAMMER","upper_body_max":0.5}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"close_range_min": 0.5, "lower_body_min": 2, "pattern": "HAMMER", "upper_body_max": 0.5}

التعريف: DERIVED local-low completion: current low<=minimum of 5 previous lows. Hammer: positive body, lower shadow>=2*body, upper shadow<=.5*body, C>=range midpoint. Engulfing: previous red,current green,O<=previous C,C>=previous O. Emit at current close.

## d68c525aee6ea4761ab5c852

الاسم: COMPLETED83_T18_CANDLE_{"body_containment":true,"pattern":"BULLISH_ENGULFING"}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"body_containment": true, "pattern": "BULLISH_ENGULFING"}

التعريف: DERIVED local-low completion: current low<=minimum of 5 previous lows. Hammer: positive body, lower shadow>=2*body, upper shadow<=.5*body, C>=range midpoint. Engulfing: previous red,current green,O<=previous C,C>=previous O. Emit at current close.

## abfcb58e4cc0aaaddc08282f

الاسم: COMPLETED83_T19_EMA_CROSS_{"fast":10,"slow":30}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"fast": 10, "slow": 30}

التعريف: SMA-seeded close EMAs; previous fast<=slow,current fast>slow.

## fccd426b718efeda493e1c7f

الاسم: COMPLETED83_T19_EMA_CROSS_{"fast":20,"slow":50}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"fast": 20, "slow": 50}

التعريف: SMA-seeded close EMAs; previous fast<=slow,current fast>slow.

## c16586fcffabdd4305344ed4

الاسم: COMPLETED83_T19_EMA_CROSS_{"fast":50,"slow":200}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"fast": 50, "slow": 200}

التعريف: SMA-seeded close EMAs; previous fast<=slow,current fast>slow.

## 73fa612b6fbf0a9825d7f9e2

الاسم: COMPLETED83_T20_MACD_{"fast":12,"signal":9,"slow":26}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"fast": 12, "signal": 9, "slow": 26}

التعريف: SMA-seeded close EMAs; MACD=EMAfast-EMAslow; signal=SMA-seeded EMA of finite MACD values; previous MACD<=signal,current MACD>signal.

## c73d71468061ae3150ba1569

الاسم: COMPLETED83_T20_MACD_{"fast":8,"signal":5,"slow":21}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"fast": 8, "signal": 5, "slow": 21}

التعريف: SMA-seeded close EMAs; MACD=EMAfast-EMAslow; signal=SMA-seeded EMA of finite MACD values; previous MACD<=signal,current MACD>signal.

## 9a817af0b0bfccc08d286b8b

الاسم: COMPLETED83_T20_MACD_{"fast":19,"signal":9,"slow":39}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"fast": 19, "signal": 9, "slow": 39}

التعريف: SMA-seeded close EMAs; MACD=EMAfast-EMAslow; signal=SMA-seeded EMA of finite MACD values; previous MACD<=signal,current MACD>signal.

## 4602cce9e55dc2d15f639e73

الاسم: COMPLETED83_T21_SUPERTREND_{"atr_length":10,"multiplier":3}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"atr_length": 10, "multiplier": 3}

التعريف: SMA-seeded Wilder ATR, first TR=H-L; basic bands HL2 +/- multiplier*ATR. Upper resets if basic<previous final upper or previous C>previous upper; lower resets if basic>previous lower or previous C<previous lower. Initial direction bearish; switch bullish when C>final upper, bearish when C<final lower. Emit bearish-to-bullish only.

## 4954c1aed16c1173c5025b19

الاسم: COMPLETED83_T21_SUPERTREND_{"atr_length":10,"multiplier":2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"atr_length": 10, "multiplier": 2}

التعريف: SMA-seeded Wilder ATR, first TR=H-L; basic bands HL2 +/- multiplier*ATR. Upper resets if basic<previous final upper or previous C>previous upper; lower resets if basic>previous lower or previous C<previous lower. Initial direction bearish; switch bullish when C>final upper, bearish when C<final lower. Emit bearish-to-bullish only.

## 8f3a4cd475913f2293cda6d0

الاسم: COMPLETED83_T21_SUPERTREND_{"atr_length":14,"multiplier":3}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"atr_length": 14, "multiplier": 3}

التعريف: SMA-seeded Wilder ATR, first TR=H-L; basic bands HL2 +/- multiplier*ATR. Upper resets if basic<previous final upper or previous C>previous upper; lower resets if basic>previous lower or previous C<previous lower. Initial direction bearish; switch bullish when C>final upper, bearish when C<final lower. Emit bearish-to-bullish only.

## 67cbce5ef286a954bb90e668

الاسم: COMPLETED83_T22_DI_ADX_{"adx_threshold":20}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"adx_threshold": 20}

التعريف: Length14 for DI/ADX. Wilder SMA seed. +DM=max(H-Hprev,0) only if strictly greater than downward movement; -DM symmetric; first DM=0. DI=100*smoothed DM/ATR; DX=100*abs(+DI--DI)/(+DI+-DI), zero sum=>0. ADX=Wilder14(DX). +DI crosses above -DI, ADX>threshold and ADX>previous ADX.

## 5882d4986c5325017c814442

الاسم: COMPLETED83_T22_DI_ADX_{"adx_threshold":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"adx_threshold": 25}

التعريف: Length14 for DI/ADX. Wilder SMA seed. +DM=max(H-Hprev,0) only if strictly greater than downward movement; -DM symmetric; first DM=0. DI=100*smoothed DM/ATR; DX=100*abs(+DI--DI)/(+DI+-DI), zero sum=>0. ADX=Wilder14(DX). +DI crosses above -DI, ADX>threshold and ADX>previous ADX.

## f06fafc7e333527786180cc4

الاسم: COMPLETED83_T23_AROON_{"length":14}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14}

التعريف: Aroon window n+1 candles, earliest equal extreme wins; index of window maximum/minimum times100/n; up crosses above down.

## 7e12b82a6fd70c70a7724cc4

الاسم: COMPLETED83_T23_AROON_{"length":25}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 25}

التعريف: Aroon window n+1 candles, earliest equal extreme wins; index of window maximum/minimum times100/n; up crosses above down.

## 984c585d912b80d7056c360e

الاسم: COMPLETED83_T24_VORTEX_{"length":14}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 14}

التعريف: VI+=sum(abs(H-Lprev),n)/sum(TR,n), VI-=sum(abs(L-Hprev),n)/sum(TR,n); +VI crosses above -VI; full n valid observations.

## b36490642e92794e78ce877d

الاسم: COMPLETED83_T24_VORTEX_{"length":21}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 21}

التعريف: VI+=sum(abs(H-Lprev),n)/sum(TR,n), VI-=sum(abs(L-Hprev),n)/sum(TR,n); +VI crosses above -VI; full n valid observations.

## aad4650a5dac2e511d7d05f9

الاسم: COMPLETED83_T25_BOLLINGER_{"length":20,"multiplier":2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 20, "multiplier": 2}

التعريف: Lower Bollinger=SMA(C,n)-multiplier*population_SD(C,n); current L<=lower and C>lower; current completed-bar band.

## 164a86b5ef3bc6897a586ac0

الاسم: COMPLETED83_T25_BOLLINGER_{"length":20,"multiplier":2.5}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 20, "multiplier": 2.5}

التعريف: Lower Bollinger=SMA(C,n)-multiplier*population_SD(C,n); current L<=lower and C>lower; current completed-bar band.

## 8ea84def80c944c5020823bb

الاسم: COMPLETED83_T25_BOLLINGER_{"length":50,"multiplier":2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 50, "multiplier": 2}

التعريف: Lower Bollinger=SMA(C,n)-multiplier*population_SD(C,n); current L<=lower and C>lower; current completed-bar band.

## 9cbe73b75473a77abdca0aa9

الاسم: COMPLETED83_T26_KELTNER_{"length":20,"multiplier":2}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"length": 20, "multiplier": 2}

التعريف: DERIVED completion: lower Keltner=SMA-seeded EMA(C,20)-2*SMA-seeded Wilder ATR20; L<=lower,C>lower.

## 269c70cf152d8bab291b5293

الاسم: COMPLETED83_T27_ROLLING_VWAP_{"negative_sigma":-1.5,"window":30}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"negative_sigma": -1.5, "window": 30}

التعريف: DERIVED completion: rolling VWAP30=sum(TP*V)/sum(V). Sigma=sqrt(mean((TP-window_current_VWAP)^2)) over same30bars, unweighted dispersion. Previous C<previous negative-sigma band and current C crosses above current VWAP. No unlimited remembered excursion.

## 6eb5ec85e1130eb413126104

الاسم: COMPLETED83_T27_ROLLING_VWAP_{"negative_sigma":-2,"window":30}

المصدر: docs/lanes/L0083-EXECUTION.md#4

النوع: bullish_candidate؛ الأصل: explicit_definition_completion_2026_10_15

الإعدادات: {"negative_sigma": -2, "window": 30}

التعريف: DERIVED completion: rolling VWAP30=sum(TP*V)/sum(V). Sigma=sqrt(mean((TP-window_current_VWAP)^2)) over same30bars, unweighted dispersion. Previous C<previous negative-sigma band and current C crosses above current VWAP. No unlimited remembered excursion.
