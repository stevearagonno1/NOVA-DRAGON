from pathlib import Path
import hashlib,json,re
import legacy52
P=Path(__file__).resolve().parent
S=P/'sources' if (P/'sources').exists() else P.parent
PIN='6d0226a03b84656e14b94dd8a37e39332cc2f68f'
definitions={
'T01':'SMA-seeded Wilder RSI; previous RSI < threshold and current RSI >= threshold; zero loss =>100, both zero=>50.',
'T02':'K=100*(C-min(L,n))/(max(H,n)-min(L,n)); D=SMA(K,d); previous K<=D and current K>D, current K and D strictly below threshold. Flat range unavailable.',
'T03':'RSI uses length n, SMA-seeded Wilder; StochRSI=(RSI-min(RSI,n))/(max(RSI,n)-min(RSI,n)), no smoothing. Previous < threshold, current >=. Flat window unavailable.',
'T04':'WilliamsR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous < threshold and current >=. Full windows; zero range unavailable.',
'T05':'CCI=(TP-SMA(TP,n))/(.015*mean(abs(TP_window-window_mean))); TP=(H+L+C)/3. Previous < threshold, current >=. Zero deviation unavailable.',
'T06':'RSI14 bullish divergence; successive confirmed price pivots, left=2 right=2, center minimum and strictly below immediate neighbors; pivot gap 5..window inclusive; price drop >=.25*ATR14 at second pivot, oscillator higher. Emit at second pivot+2; update previous at every confirmed pivot.',
'T07':'Same confirmed-pivot divergence using SMA-seeded MACD12/26/9 histogram; available only two bars after second pivot.',
'T08':'Same confirmed-pivot divergence using OBV initialized zero, adding/subtracting base volume on close change, unchanged for equal close.',
'T09':'Same confirmed-pivot divergence using actual taker-buy quote volume / total quote volume; zero denominator unavailable.',
'T10':'Volume z uses prior 100 bars, minimum 50 finite observations, population SD. z>=threshold AND (C-L)/(H-L)>=2/3; zero range or SD unavailable. Evaluated each qualifying closed candle, not edge-only.',
'T11':'Actual taker-buy quote ratio z against prior 100 bars, minimum 50 finite, population SD; z>=threshold on each closed candle. Zero denominator or SD unavailable.',
'T12':'Force=(C-Cprevious)*base_volume; SMA-seeded EMA13 crosses from <=0 to >0.',
'T13':'CMF=sum(((2*C-H-L)/(H-L))*V,n)/sum(V,n); zero H-L contributes zero money-flow multiplier; zero sum V unavailable. Cross <=0 to >0.',
'T14':'Current L < minimum of prior window lows AND C > same minimum; every qualifying bar.',
'T15':'Three-bar bullish FVG: current L > H two bars ago; every qualifying bar, available at current close.',
'T16':'DERIVED context completion: latest n prior lows minimum < preceding n lows minimum, and C crosses above maximum of n prior highs; previous C<=previous corresponding channel and current C>current channel.',
'T17':'Bullish lower Donchian recovery: current L < minimum prior n lows and current C > that minimum. Distinct from historical upper-break failure.',
'T18':'DERIVED local-low completion: current low<=minimum of 5 previous lows. Hammer: positive body, lower shadow>=2*body, upper shadow<=.5*body, C>=range midpoint. Engulfing: previous red,current green,O<=previous C,C>=previous O. Emit at current close.',
'T19':'SMA-seeded close EMAs; previous fast<=slow,current fast>slow.',
'T20':'SMA-seeded close EMAs; MACD=EMAfast-EMAslow; signal=SMA-seeded EMA of finite MACD values; previous MACD<=signal,current MACD>signal.',
'T21':'SMA-seeded Wilder ATR, first TR=H-L; basic bands HL2 +/- multiplier*ATR. Upper resets if basic<previous final upper or previous C>previous upper; lower resets if basic>previous lower or previous C<previous lower. Initial direction bearish; switch bullish when C>final upper, bearish when C<final lower. Emit bearish-to-bullish only.',
'T22':'Length14 for DI/ADX. Wilder SMA seed. +DM=max(H-Hprev,0) only if strictly greater than downward movement; -DM symmetric; first DM=0. DI=100*smoothed DM/ATR; DX=100*abs(+DI--DI)/(+DI+-DI), zero sum=>0. ADX=Wilder14(DX). +DI crosses above -DI, ADX>threshold and ADX>previous ADX.',
'T23':'Aroon window n+1 candles, earliest equal extreme wins; index of window maximum/minimum times100/n; up crosses above down.',
'T24':'VI+=sum(abs(H-Lprev),n)/sum(TR,n), VI-=sum(abs(L-Hprev),n)/sum(TR,n); +VI crosses above -VI; full n valid observations.',
'T25':'Lower Bollinger=SMA(C,n)-multiplier*population_SD(C,n); current L<=lower and C>lower; current completed-bar band.',
'T26':'DERIVED completion: lower Keltner=SMA-seeded EMA(C,20)-2*SMA-seeded Wilder ATR20; L<=lower,C>lower.',
'T27':'DERIVED completion: rolling VWAP30=sum(TP*V)/sum(V). Sigma=sqrt(mean((TP-window_current_VWAP)^2)) over same30bars, unweighted dispersion. Previous C<previous negative-sigma band and current C crosses above current VWAP. No unlimited remembered excursion.'}
rows=[]
def legacy_spec(name):
    nums=[float(v) for v in re.findall(r'-?\d+(?:\.\d+)?',name)]
    if name.startswith('RSI'):
        if 'divergence' in name:return {'length':int(nums[0]),'lookback':20,'left':2,'right':2},'Successive confirmed price pivot lows, left=right=2. Emit at center+2 when new pivot low is lower and RSI at that pivot is finite and higher than previous pivot RSI, center separation<=20. Update preceding pivot on every confirmed pivot. Pivot equals minimum and is strictly below its immediate neighbors.'
        return {'length':int(nums[0]),'threshold':nums[1]},'Historical RSI crosses from strictly below threshold to greater than or equal threshold.'
    if name.startswith('Stoch'):return {'length':int(nums[0]),'d_length_unused_in_signal':int(nums[1]),'threshold':nums[2]},'Raw K=100*(C-min(L,n))/(max(H,n)-min(L,n)); crosses from strictly below threshold to >=threshold. Flat denominator unavailable. D does not gate this signal.'
    if name.startswith('BB'):return {'length':int(nums[0]),'multiplier':nums[1],'ddof':0},'Lower=SMA(C,n)-multiplier*population_SD(C,n). Previous C<=previous lower and current C>current lower.'
    if name.startswith('EMA_x'):return {'fast':int(nums[0]),'slow':int(nums[1])},'Previous fast EMA<=slow EMA and current fast EMA>slow EMA.'
    if name.startswith('PX_x'):return {'length':int(nums[0])},'Previous C<=previous EMA and current C>current EMA.'
    if name.startswith('MACD'):return dict(zip(['fast','slow','signal'],map(int,nums))),'MACD=EMAfast-EMAslow; signal=EMA(MACD). Previous MACD<=signal and current MACD>signal.'
    if name.startswith('Aroon'):return {'length':int(nums[0]),'tie':'earliest_extreme'},'Window n+1; up/down=100*index of earliest maximum/minimum divided by n. Previous up<=down,current up>down.'
    if name.startswith('Donchian'):return {'length':int(nums[0]),'exclude_current':True},'Upper=max prior n highs. '+('Current H>upper and C<=upper; upper breakout rejection, not bullish lower reclaim.' if name.endswith('fail') else 'Current C>upper on every qualifying bar.')
    if name.startswith('VolSpike'):return {'window':50,'z_threshold':nums[0],'ddof':0,'includes_current':True},'Current volume z against full 50-bar window including current, population SD; z>=threshold. Activity only; zero SD unavailable.'
    if name.startswith('TakerRatioZ'):return {'window':50,'z_threshold':nums[0],'ddof':0,'includes_current':True},'Ratio=actual taker-buy base volume/base volume. Ratio z against full current-inclusive50window, population SD; z>=threshold. Zero volume or SD unavailable.'
    if name.startswith('TakerRatio_gt'):return {'threshold':nums[0]},'Actual taker-buy base volume/base volume strictly greater than threshold on every bar; zero volume unavailable.'
    if name.startswith('CCI'):return {'length':int(nums[0]),'threshold':nums[1]},'TP=HLC3; CCI=(TP-SMA(TP,n))/(.015*mean absolute deviation of TP window from its own mean); previous<threshold,current>=threshold; zero deviation unavailable.'
    if name.startswith('Williams'):return {'length':int(nums[0]),'threshold':nums[1]},'WR=-100*(max(H,n)-C)/(max(H,n)-min(L,n)); previous<threshold,current>=threshold; zero range unavailable.'
    if name.startswith('MFI'):return {'length':int(nums[0]),'threshold':nums[1]},'TP=HLC3; rawflow=TP*V. Sum positive/negative flow by sign of TP change, equal contributes zero; MFI=100-100/(1+positive/negative). Zero negative unavailable. Previous<threshold,current>=threshold.'
    if name=='Hammer':return {'lower_body_min':2,'upper_body_max':1},'Body=abs(C-O)>0,range>0,lower shadow>=2*body,upper shadow<=body. No decline context or required green close; every qualifying candle.'
    if name=='BullEngulfing':return {},'Previous red,current green,current O<=previous C,current C>=previous O; every qualifying candle, no extra decline context.'
    if name=='FVG_single':return {'lookback':2},'Current L>H two bars earlier; current completed candle, every qualifying candle.'
    raise KeyError(name)
def add(r):
    identity={k:r[k] for k in ('origin','name','parameters','definition')}
    r['id']=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:24]
    r.update(frames_minutes=[1,5,15,60],available_at='current completed candle close; pivot confirmation at detection candle',combines_other_registered_signals=False,market_validated=False)
    rows.append(r)
for name in legacy52.SETTINGS_52:
    params,definition=legacy_spec(name)
    r=dict(name=name,family=name.split('_')[0],parameters=params,implementation='legacy52',origin='historical_executable_52',source='tools/l0090/indicators84.py',source_pin=PIN,definition=definition,kind='activity_only' if name.startswith('VolSpike') else 'historical_nonbullish_reference' if name=='Donchian20_fail' else 'bullish_candidate',included_in_bullish_study=name!='Donchian20_fail',known_differences=[])
    if name.startswith('Stoch'):r['known_differences'].append('Historical signal is K threshold crossing, NOT K/D crossing; D smoothing parameter is unused by this trigger.')
    if name=='Donchian20_fail':r['known_differences'].append('Upper breakout rejection: H>prior upper,C<=upper. Preserved as reference; bullish lower-channel recovery is a separate T17 ID.')
    r['initialization']='Historical first-value EWM with min_periods; RSI/MFI zero-loss denominator => unavailable; no seed substitution.'
    add(r)
for pattern,values in [('hammer',[2,3]),('engulf',[1,1.25]),('morning',[.5,1])]:
    for v in values:
        detail={'hammer':'body>0 and <=.35*range, lower>=ratio*body, upper<=body, C>=L+.6*range','engulf':'previous red,current green,O<=previous C,C>=previous O,body>=ratio*previous body','morning':'first red with body>=.5*range,middle body<=.3*first body,last green with body>=.5*range and C>=first C+fraction*first body; first and last ranges>0; no opening gap required'}[pattern]
        add(dict(name=f'CANDLE92_{pattern}_{v}',family=pattern,parameters={'pattern':pattern,'value':v},implementation='candle92',origin='historical_candle92_standalone',source='history/research/hyp_lab_out/L0092-candle-confirmation/REGISTRATION.md',source_pin=PIN,definition=detail+'; context C[t-1]<C[t-7]; emit false-to-true transition only; no CCI condition.',kind='bullish_candidate',included_in_bullish_study=True))
drafts=json.loads((S/'HISTORICAL-GRIDS.json').read_text())['records']
for r in drafts:
    if not r['family'].startswith('T'):continue
    code=r['family'].split('_')[0]
    # TURTLE is in the other paper; only numeric T01..T27 codes.
    if code not in definitions:continue
    add(dict(name='COMPLETED83_'+r['family']+'_'+json.dumps(r['parameters'],sort_keys=True,separators=(',',':')),family=r['family'],parameters=r['parameters'],implementation='completed83',origin='explicit_definition_completion_2026_10_15',source=r['source_document'],source_pin=PIN,source_draft_id=r['draft_id'],definition=definitions[code],kind='bullish_candidate',included_in_bullish_study=True,changes_from_original='Completed conventions are explicitly registered prospective derivatives; not claimed identical to old underspecified paper. Divergence waits for confirmation; no past-dated alerts.',original_definition_status=r['status']))
assert len(rows)==134 and len({r['id'] for r in rows})==134
registry={'status':'IMPLEMENTED_REGISTRY_REQUIRES_VALIDATION_EVIDENCE_NOT_ALL_SOURCE_RELEASE','source_pin':PIN,'count':len(rows),'variants':rows,'signal_only':True,'no_market_selection':True,'legacy_code_sha256':hashlib.sha256((P/'legacy52.py').read_bytes()).hexdigest(),'all_library_sources_implemented':False}
(P/'REGISTRY.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
coverage={'source_pin':PIN,'historical_drafts':[{'draft_id':r['draft_id'],'source':r['source_document'],'status':'EXPLICIT_DERIVATIVE_IMPLEMENTED_ORIGINAL_NOT_REPLACED' if any(v.get('source_draft_id')==r['draft_id'] for v in rows) else 'ORIGINAL_TRIGGER_RECONCILIATION_PENDING'} for r in drafts], 'library_sources':[{'path':f['path'],'git_sha':f['git_sha'],'status':'COMPONENT_DECOMPOSITION_PENDING_NOT_COUNTED_AS_TESTED'} for f in json.loads((S/'RESOLVED-PARAMETERS.json').read_text())['files']], 'input_declarations':5940,'declarations_are_not_signal_variant_count':True,'final_all_source_paper_ready':False}
(P/'COVERAGE.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'registered':len(rows),'canonical_originals':52,'candles':6,'explicit_completed_derivatives':76,'all_library_sources_implemented':False}))
