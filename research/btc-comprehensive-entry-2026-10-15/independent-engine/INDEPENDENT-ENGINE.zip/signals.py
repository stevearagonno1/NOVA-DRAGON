"""Independent closed-candle signals. No outcomes, trading, drawings or network.

Historical definitions remain unchanged. Completed definitions have separate IDs.
"""
import hashlib,json
import numpy as np
import pandas as pd
import legacy52 as legacy

def lag(x,n=1):
    a=np.asarray(x,dtype=float);out=np.full(len(a),np.nan)
    if n<len(a):out[n:]=a[:-n]
    return out
def rolling(x,n,op,min_periods=None):
    r=pd.Series(x,dtype=float).rolling(n,min_periods=n if min_periods is None else min_periods)
    return (r.std(ddof=0) if op=='std' else getattr(r,op)()).to_numpy()
def divide(a,b):
    a,b=np.broadcast_arrays(np.asarray(a,float),np.asarray(b,float))
    return np.divide(a,b,out=np.full(a.shape,np.nan),where=np.isfinite(b)&(b!=0))
def seeded(x,n,wilder=False):
    out=np.full(len(x),np.nan);buf=[];v=None;alpha=1/n if wilder else 2/(n+1)
    for i,a in enumerate(x):
        if not np.isfinite(a):buf=[];v=None;continue
        if v is None:
            buf.append(a)
            if len(buf)==n:v=sum(buf)/n
        else:v=(v*(n-1)+a)/n if wilder else alpha*a+(1-alpha)*v
        if v is not None:out[i]=v
    return out
def rsi(c,n):
    change=c-lag(c);up=seeded(np.maximum(change,0),n,True);dn=seeded(np.maximum(-change,0),n,True)
    r=100-100/(1+divide(up,dn));r[(dn==0)&(up>0)]=100;r[(dn==0)&(up==0)]=50;return r
def tr(d):
    prev=lag(d['c']);x=np.maximum.reduce([d['h']-d['l'],abs(d['h']-prev),abs(d['l']-prev)])
    if len(x):x[0]=d['h'][0]-d['l'][0]
    return x
def cross(a,b):return (lag(a)<=lag(np.broadcast_to(b,np.shape(a))))&(np.asarray(a)>b)
def reclaim(a,b):return (lag(a)<b)&(np.asarray(a)>=b)
def pulse(a):return a & ~np.r_[False,a[:-1]]
def cmf(d,n):
    spread=d['h']-d['l'];m=divide(2*d['c']-d['h']-d['l'],spread);m[spread==0]=0
    return divide(rolling(m*d['v'],n,'sum'),rolling(d['v'],n,'sum'))
def obv(d):return np.cumsum(np.nan_to_num(np.sign(d['c']-lag(d['c'])))*d['v'])
def macd(d,f,s,g):
    line=seeded(d['c'],f)-seeded(d['c'],s);signal=seeded(line,g);return line,signal
def directionals(d,n):
    up=d['h']-lag(d['h']);dn=lag(d['l'])-d['l']
    plus=np.where((up>dn)&(up>0),up,0.);minus=np.where((dn>up)&(dn>0),dn,0.)
    a=seeded(tr(d),n,True);p=100*divide(seeded(plus,n,True),a);m=100*divide(seeded(minus,n,True),a)
    den=p+m;dx=100*divide(abs(p-m),den);dx[den==0]=0
    return p,m,seeded(dx,n,True)
def supertrend(d,n,k):
    a=seeded(tr(d),n,True);mid=(d['h']+d['l'])/2;up=mid+k*a;lo=mid-k*a
    side=np.full(len(a),np.nan);fu=fl=None;previous=-1
    for i in range(len(a)):
        if not np.isfinite(a[i]):continue
        if fu is None:fu,fl=up[i],lo[i];side[i]=-1;continue
        old_u,old_l=fu,fl
        fu=up[i] if up[i]<old_u or d['c'][i-1]>old_u else old_u
        fl=lo[i] if lo[i]>old_l or d['c'][i-1]<old_l else old_l
        current=1 if previous==-1 and d['c'][i]>fu else -1 if previous==1 and d['c'][i]<fl else previous
        side[i]=current;previous=current
    return cross(side,0)

def candle(d,pattern,value):
    o,h,l,c=(d[x] for x in ('o','h','l','c'));body=abs(c-o);ran=h-l
    decline=lag(c)<lag(c,7)
    if pattern=='hammer':cond=(body>0)&(body<=.35*ran)&(np.minimum(o,c)-l>=value*body)&(h-np.maximum(o,c)<=body)&(c>=l+.6*ran)
    elif pattern=='engulf':cond=(lag(c)<lag(o))&(c>o)&(o<=lag(c))&(c>=lag(o))&(body>=value*lag(body))
    elif pattern=='morning':cond=(lag(c,2)<lag(o,2))&(lag(body,2)>=.5*lag(ran,2))&(lag(body)<=.3*lag(body,2))&(c>o)&(body>=.5*ran)&(c>=lag(c,2)+value*lag(body,2))&(lag(ran,2)>0)&(ran>0)
    else:raise ValueError(pattern)
    return pulse(cond&decline)

def completed83(d,f,p):
    c,h,l,v=(d[x] for x in ('c','h','l','v'));length=p.get('length');code=f.split('_')[0]
    if code=='T01':return reclaim(rsi(c,length),p['threshold'])
    if code=='T02':
        k,dd=legacy.stochastic(h,l,c,length,p['smooth']);return cross(k,dd)&(k<p['threshold'])&(dd<p['threshold'])
    if code=='T03':
        r=rsi(c,length);ll=rolling(r,length,'min');hh=rolling(r,length,'max');return reclaim(divide(r-ll,hh-ll),p['threshold'])
    if code=='T04':return reclaim(legacy.williams_r(h,l,c,length),p['threshold'])
    if code=='T05':return reclaim(legacy.cci(h,l,c,length),p['threshold'])
    if code in ('T06','T07','T08','T09'):
        if code=='T06':x=rsi(c,14)
        elif code=='T07':a,b=macd(d,12,26,9);x=a-b
        elif code=='T08':x=obv(d)
        else:x=divide(d['tbq'],d['qv'])
        a=seeded(tr(d),14,True);out=np.zeros(len(c),bool);last=None
        for i in range(4,len(c)):
            j=i-2
            if l[j]==min(l[j-2:j+3]) and l[j]<l[j-1] and l[j]<l[j+1]:
                if last is not None and p['min_gap']<=j-last<=p['window']:
                    out[i]=np.isfinite(x[j]) and np.isfinite(x[last]) and l[last]-l[j]>=p['min_price_drop_atr']*a[j] and x[j]>x[last]
                last=j
        return out
    if code in ('T10','T11'):
        x=v if code=='T10' else divide(d['tbq'],d['qv']);prior=lag(x)
        z=divide(x-rolling(prior,p['prior_window'],'mean',p['min_observations']),rolling(prior,p['prior_window'],'std',p['min_observations']))
        cond=z>=p['z']
        return cond & (divide(c-l,h-l)>=p['close_range_fraction_min']) if code=='T10' else cond
    if code=='T12':return cross(seeded((c-lag(c))*v,p['ema_length']),0)
    if code=='T13':return cross(cmf(d,length),0)
    if code in ('T14','T17'):
        lo=rolling(lag(l),p['window'],'min');return (l<lo)&(c>lo)
    if code=='T15':return legacy.fvg_bull(h,l)
    if code=='T16':
        n=p['window'];hi=rolling(lag(h),n,'max');recent=rolling(lag(l),n,'min');older=rolling(lag(l,n+1),n,'min')
        return cross(c,hi)&(recent<older)
    if code=='T18':
        body=abs(c-d['o']);cond=legacy.bullish_engulfing(d['o'],c) if p['pattern']=='BULLISH_ENGULFING' else (body>0)&(np.minimum(d['o'],c)-l>=2*body)&(h-np.maximum(d['o'],c)<=.5*body)&(c>=(h+l)/2)
        return cond&(l<=rolling(lag(l),5,'min'))
    if code=='T19':return cross(seeded(c,p['fast']),seeded(c,p['slow']))
    if code=='T20':return cross(*macd(d,p['fast'],p['slow'],p['signal']))
    if code=='T21':return supertrend(d,p['atr_length'],p['multiplier'])
    if code=='T22':
        a,b,x=directionals(d,14);return cross(a,b)&(x>p['adx_threshold'])&(x>lag(x))
    if code=='T23':return cross(*legacy.aroon(h,l,length))
    if code=='T24':
        den=rolling(tr(d),length,'sum');a=divide(rolling(abs(h-lag(l)),length,'sum'),den);b=divide(rolling(abs(l-lag(h)),length,'sum'),den);return cross(a,b)
    if code=='T25':
        lower=rolling(c,length,'mean')-p['multiplier']*rolling(c,length,'std');return (l<=lower)&(c>lower)
    if code=='T26':
        lower=seeded(c,length)-p['multiplier']*seeded(tr(d),length,True);return (l<=lower)&(c>lower)
    if code=='T27':
        n=p['window'];tp=(h+l+c)/3;vw=divide(rolling(tp*v,n,'sum'),rolling(v,n,'sum'))
        # Population dispersion of TP around current volume-weighted mean.
        sd=np.sqrt(np.maximum(rolling(tp*tp,n,'mean')-2*vw*rolling(tp,n,'mean')+vw*vw,0))
        band=vw+p['negative_sigma']*sd;return (lag(c)<lag(band))&cross(c,vw)
    raise KeyError(f)

def calculate(d,r):
    for k in ('o','h','l','c','v','tbv'):assert k in d
    if r['implementation']=='legacy52':return legacy.build_one(d,r['name'])
    if r['implementation']=='candle92':return candle(d,**r['parameters'])
    if r['implementation']=='completed83':return completed83(d,r['family'],r['parameters'])
    raise ValueError('No executable definition: '+r['id'])

def states(d):
    """Proposed state dictionary, SMA-seeded; not a signal or a claimed market law."""
    c=d['c'];e=seeded(c,20);m,s=macd(d,12,26,9);r=rsi(c,14);a=seeded(tr(d),14,True)
    axes=np.column_stack([c-e,e-lag(e,5),m-s,r-lag(r,5),divide(a,lag(a,5))-1,divide(d['v'],rolling(lag(d['v']),60,'mean'))-1])
    valid=np.isfinite(axes).all(axis=1);ids=np.full(len(c),-1,dtype=np.int16)
    ids[valid]=((np.sign(axes[valid]).astype(int)+1)*np.array([243,81,27,9,3,1])).sum(axis=1)
    return ids
