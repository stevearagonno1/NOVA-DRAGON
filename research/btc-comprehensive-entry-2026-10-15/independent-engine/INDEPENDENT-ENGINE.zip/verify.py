"""Short deterministic preparation checks. No market accuracy is measured."""
from pathlib import Path
import hashlib,json,time,decimal
import numpy as np
import signals as s
P=Path(__file__).resolve().parent
def fixture(n=480):
    r=np.random.default_rng(20261015);c=100+np.cumsum(r.normal(0,.8,n));o=np.r_[c[0]+.2,c[:-1]]
    h=np.maximum(o,c)+r.uniform(.01,1,n);l=np.minimum(o,c)-r.uniform(.01,1,n);v=r.uniform(1,200,n)
    ratio=r.uniform(.25,.75,n);qv=v*(h+l+c)/3
    return dict(o=o,h=h,l=l,c=c,v=v,tbv=v*ratio,qv=qv,tbq=qv*ratio)
def average_ref(a,n,wilder=False):
    D=decimal.Decimal;out=np.full(len(a),np.nan);previous=None;window=[]
    with decimal.localcontext() as context:
        context.prec=40
        weight=D(1)/D(n) if wilder else D(2)/D(n+1)
        for i,x in enumerate(a):
            if not np.isfinite(x):window=[];previous=None;continue
            value=D(str(float(x)))
            if previous is None:
                window.append(value)
                if len(window)==n:previous=sum(window)/D(n)
            else:previous=previous*(1-weight)+value*weight
            if previous is not None:out[i]=float(previous)
    return out
def candle_ref(d,pattern,value):
    raw=[]
    for i in range(len(d['c'])):
        ok=False
        if i>=7 and d['c'][i-1]<d['c'][i-7]:
            o,h,l,c=(d[k][i] for k in ('o','h','l','c'));body=abs(c-o);span=h-l
            if pattern=='hammer':ok=body>0 and body<=.35*span and min(o,c)-l>=value*body and h-max(o,c)<=body and c>=l+.6*span
            elif pattern=='engulf':
                po,pc=d['o'][i-1],d['c'][i-1];ok=pc<po and c>o and o<=pc and c>=po and body>=value*abs(pc-po)
            else:
                a=i-2;first=abs(d['c'][a]-d['o'][a]);fs=d['h'][a]-d['l'][a];mid=abs(d['c'][i-1]-d['o'][i-1])
                ok=d['c'][a]<d['o'][a] and first>=.5*fs and mid<=.3*first and c>o and body>=.5*span and c>=d['c'][a]+value*first and fs>0 and span>0
        raw.append(bool(ok))
    return np.array([x and (i==0 or not raw[i-1]) for i,x in enumerate(raw)])
def main():
    start=time.monotonic();registry=json.loads((P/'REGISTRY.json').read_text());rows=registry['variants'];d=fixture();counts={};prefix_checks=0
    for r in rows:
        out=s.calculate(d,r);assert out.dtype==bool and len(out)==len(d['c']),r['id'];counts[r['id']]=int(out.sum())
        for n in (79,143,317):
            short={k:a[:n] for k,a in d.items()};assert np.array_equal(s.calculate(short,r),out[:n]),('prefix',r['name'],n);prefix_checks+=1
    # Independent candle formulas and positive, negative manual fixtures.
    candle_checks=0
    for r in rows:
        if r['implementation']=='candle92':
            assert np.array_equal(s.calculate(d,r),candle_ref(d,**r['parameters']));candle_checks+=1
    e=fixture(12);e['c'][:]=20;e['c'][0]=30;e['c'][6]=20
    e['o'][7]=19;e['c'][7]=20;e['h'][7]=20.2;e['l'][7]=15
    assert s.candle(e,'hammer',2)[7] and s.candle(e,'hammer',3)[7]
    e['l'][7]=16.5;assert s.candle(e,'hammer',2)[7] and not s.candle(e,'hammer',3)[7]
    e['o'][6]=21;e['c'][6]=20;e['o'][7]=20;e['c'][7]=21.1
    assert s.candle(e,'engulf',1)[7] and not s.candle(e,'engulf',1.25)[7]
    e['o'][5]=24;e['c'][5]=20;e['h'][5]=25;e['l'][5]=19;e['o'][6]=20;e['c'][6]=20.1;e['o'][7]=20;e['c'][7]=22.5;e['l'][7]=20;e['h'][7]=23
    assert s.candle(e,'morning',.5)[7] and not s.candle(e,'morning',1)[7]
    decimal_checks=0
    for n in (7,14,20,26):
        for w in (False,True):
            a=s.seeded(d['c'],n,w);b=average_ref(d['c'],n,w);np.testing.assert_allclose(a,b,rtol=0,atol=1e-10,equal_nan=True);decimal_checks+=len(a)
    delta=np.r_[np.nan,np.diff(d['c'])];gain=average_ref(np.maximum(delta,0),14,True);loss=average_ref(np.maximum(-delta,0),14,True)
    expected=100-100/(1+gain/loss);np.testing.assert_allclose(s.rsi(d['c'],14),expected,rtol=0,atol=1e-10,equal_nan=True);decimal_checks+=len(expected)
    # Distinct upper-failure and lower-recovery definitions must remain distinct.
    lo=s.rolling(s.lag(d['l']),20,'min');expected=(d['l']<lo)&(d['c']>lo)
    lower=s.completed83(d,'T17_DONCHIAN_FAIL',{'window':20});assert np.array_equal(lower,expected)
    upper=s.legacy.build_one(d,'Donchian20_fail');assert np.any(lower!=upper)
    # Original 52 implementation is reused byte-for-byte; no claim that this
    # routing equivalence independently verifies its mathematical formulas.
    masks=s.legacy.build_masks(d)
    for r in rows:
        if r['implementation']=='legacy52':assert np.array_equal(s.calculate(d,r),masks[r['name']])
    ids=s.states(d);assert set(ids).issubset(set(range(729))|{-1})
    for n in (79,143,317):assert np.array_equal(s.states({k:a[:n] for k,a in d.items()}),ids[:n])
    flat={k:np.full(480,100. if k in ('o','h','l','c') else 0.) for k in d}
    for r in rows:assert not s.calculate(flat,r).any(),('flat',r['name'])
    assert (s.states(flat)==-1).all()
    result={'status':'PASS_SCOPED_CALCULATION_AND_CAUSALITY_CHECKS','variants':len(rows),'prefix_comparisons':prefix_checks,'decimal_value_positions':decimal_checks,'scalar_candle_comparisons':candle_checks*len(d['c']),'manual_candle_checks':4,'flat_zero_volume_variants':len(rows),'legacy_routing_equivalence_checks':52,'state_prefix_checks':3,'all_formulas_independently_verified':False,'all_library_sources_ready':False,'market_accuracy_measured':False,'zero_signal_variants_in_fixture':[k for k,v in counts.items() if v==0],'fixture_signal_counts':counts,'elapsed_seconds':time.monotonic()-start}
    (P/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('fixture_signal_counts','zero_signal_variants_in_fixture')}))
if __name__=='__main__':main()
