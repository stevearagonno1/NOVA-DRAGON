"""One preparation rehearsal: independent variants x frames x causal states.
This command intentionally accepts no market input and is not a production paper.
"""
from pathlib import Path
import argparse,csv,gzip,hashlib,json,time
import numpy as np
from signals import calculate,states
from verify import fixture
from outcomes import outcomes,describe
P=Path(__file__).resolve().parent
def aggregate(d,frame):
    n=len(d['c']);assert n%frame==0
    z={k:a.reshape(-1,frame) for k,a in d.items()}
    return {'o':z['o'][:,0],'h':z['h'].max(axis=1),'l':z['l'].min(axis=1),'c':z['c'][:,-1],**{k:z[k].sum(axis=1) for k in ('v','tbv','qv','tbq')}}
def run(out):
    start=time.monotonic();out.mkdir(parents=True,exist_ok=True)
    registry=json.loads((P/'REGISTRY.json').read_text());rows=registry['variants'];d=fixture(14400)
    prices=np.rint(d['c']*100000000).astype(np.int64);labels=outcomes(prices)
    summaries=[];event_count=0;zero_cells=0
    fields=['variant_id','kind','frame_minutes','state_id','available_minute','reference_close_1e8','prior_direction','next_direction','next_change_minute','first_above_minute','wait_minutes','observed_minutes']
    with gzip.open(out/'alerts.csv.gz','wt',newline='') as f:
        writer=csv.writer(f);writer.writerow(fields)
        for frame in (1,5,15,60):
            bars=aggregate(d,frame);context=states(bars);close_idx=np.arange(frame-1,len(prices),frame)
            baseline=np.zeros((730,4),dtype=np.int64)
            for j,index in enumerate(close_idx):
                result=describe(prices,labels,int(index));cell=context[j]+1
                baseline[cell,0]+=1;baseline[cell,1+({1:0,-1:1,0:2}[result['next_direction']])]+=1
            packed={}
            for r in rows:
                mask=calculate(bars,r);packed[r['id']]=np.packbits(mask,bitorder='little')
                counts=np.zeros((730,4),dtype=np.int64)
                for j in np.flatnonzero(mask):
                    index=int(close_idx[j]);result=describe(prices,labels,index);cell=int(context[j])+1
                    counts[cell,0]+=1;counts[cell,1+({1:0,-1:1,0:2}[result['next_direction']])]+=1
                    writer.writerow([r['id'],r['kind'],frame,int(context[j]),index+1,int(prices[index]),result['prior_direction'],result['next_direction'],'' if result['next_change_index']<0 else result['next_change_index']+1,'' if result['first_above_index']<0 else result['first_above_index']+1,result['wait_minutes'],result['observed_minutes']]);event_count+=1
                assert counts[:,0].sum()==mask.sum()
                for cell in range(730):
                    n,up,down,censored=map(int,counts[cell]);bn,bu,bd,bc=map(int,baseline[cell]);zero_cells+=n==0
                    summaries.append([r['id'],frame,cell-1,n,up,down,censored,bn,bu,bd,bc])
            np.savez_compressed(out/f'masks-{frame}m.npz',**packed,state_id=context,close_index=close_idx)
    with gzip.open(out/'summary.csv.gz','wt',newline='') as f:
        w=csv.writer(f);w.writerow(['variant_id','frame_minutes','state_id','signals','next_up','next_down','next_unobserved','baseline_bars','baseline_up','baseline_down','baseline_unobserved']);w.writerows(summaries)
    # Audit raw evidence independently from the in-memory summary counters.
    groups={};count=0
    with gzip.open(out/'alerts.csv.gz','rt',newline='') as f:
        for r in csv.DictReader(f):
            key=(r['variant_id'],int(r['frame_minutes']),int(r['state_id']));a=groups.setdefault(key,[0,0,0,0]);direction=int(r['next_direction']);a[0]+=1;a[1+{1:0,-1:1,0:2}[direction]]+=1;count+=1
            t=int(r['available_minute']);assert t%int(r['frame_minutes'])==0
            for k in ('next_change_minute','first_above_minute'):
                if r[k]:assert int(r[k])>t
    assert count==event_count
    for vid,frame,state,n,u,dn,c,*_ in summaries:assert groups.get((vid,frame,state),[0]*4)==[n,u,dn,c]
    expected=len(rows)*4*730;assert len(summaries)==expected
    # Future-outcome reference: a separate brute-force scan on sampled positions.
    for i in (0,60,1000,14300,14399):
        assert labels[0][i]==next((j for j in range(i+1,len(prices)) if prices[j]>prices[i]),-1)
        assert labels[1][i]==next((j for j in range(i+1,len(prices)) if prices[j]!=prices[i]),-1)
    files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.name not in ('RESULT.json','REPORT.md') and p.is_file()}
    result={'status':'PASS_SYNTHETIC_INTEGRATION_ONLY','variants':len(rows),'variant_frame_series':len(rows)*4,'state_rows_including_unavailable':len(summaries),'zero_signal_cells':zero_cells,'alert_rows':event_count,'raw_summary_reconciled':True,'signal_availability_checked':True,'outcome_reference_checks':10,'market_data_used':False,'all_source_ready':False,'all_formulas_independently_verified':False,'future_return_or_horizon_cutoff':None,'elapsed_seconds':time.monotonic()-start,'files_sha256':files}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'REPORT.md').write_text('# فحص ربط المحرك المستقل\n\nنجح مسار الحساب والتسجيل ومطابقة الأحداث بالملخص على بيانات اصطناعية فقط.\n\n'+f"حُسبت {len(rows)} هوية نسخة على أربعة أطر، مع {len(summaries)} صف حالة يشمل الحالات الصفرية وغير المتاحة.\n\n"+'هذه أعداد فحص برمجي وليست دقة سوق أو توصية تداول. التعريفات التاريخية والمشتقة منفصلة، والفشل العلوي لدونشيان مرجع غير صعودي محفوظ. النسخ ذات activity_only لا توصف بأنها إشارات شراء.\n\nالورقة الشاملة لم تصبح جاهزة؛ بقي استكمال مصادر المكتبة ومراجعة جميع الصيغ والتجهيز الكامل للتنفيذ والنشر.\n')
    print(json.dumps({k:v for k,v in result.items() if k!='files_sha256'}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);run(p.parse_args().out)
